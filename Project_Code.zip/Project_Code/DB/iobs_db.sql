-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 14, 2021 at 09:49 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `iobs_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE IF NOT EXISTS `books` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `isbn` varchar(50) NOT NULL,
  `category_ids` text NOT NULL,
  `author` text NOT NULL,
  `publisher` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `dimensions` varchar(50) NOT NULL,
  `weight` decimal(10,3) NOT NULL,
  `price` float NOT NULL,
  `discount_per` int(3) NOT NULL,
  `image_path` text NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `stock_balance` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=46 ;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `isbn`, `category_ids`, `author`, `publisher`, `description`, `dimensions`, `weight`, `price`, `discount_per`, `image_path`, `date_created`, `stock_balance`) VALUES
(7, 'COMPUTING STUDENT BOOK - 4', '9780198497820', '9', 'GENERAL', 'OXFORD UNIVERSITY PRESS', 'A complete six-year primary computing course that takes a real-life, project-based approach to teaching young learners the vital computing skills they will need for the digital world. Each unit builds a series of skills towards the creation of a final project, with topics ranging from designing your own robot to programming simple games and designing and creating web pages', '', '0.000', 2345, 0, '1623087360_download.jpg', '2021-06-07 23:06:56', 31),
(8, 'THE MISSING SISTER: THE SEVEN SISTERS BOOK 7', '9781509840182', '14', 'Lucinda Riley', 'MACMILLAN EXPORT OME', 'From the Sunday Times number one bestselling author Lucinda Riley, The Missing Sister is the seventh instalment in the multimillion-copy epic series The Seven Sisters.\r\n\r\nThe six Dâ€™ApliÃ¨se sisters have each been on their own incredible journey to discover their heritage, but they still have one question left unanswered: who and where is the seventh sister?', '', '0.000', 5250, 0, '1623088740_fiction Mising Sister.jpg', '2021-06-07 23:29:51', 32),
(9, 'THE OTHER BLACK GIRL', '9781526630384', '14', '9781526630384', 'Bloomsbury', 'xdcd', '', '0.000', 3250, 25, '1623089940_the othr black girl.jpg', '2021-06-07 23:49:28', 37),
(10, 'THE 8-WEEK BLOOD SUGAR DIET', '9781925368420', '15', 'Dr Michael Mosley', 'Dr Michael Mosley', 'Our modern diet, high in sugar and easily digestible carbohydrates, is not only making us fat, but is putting us at risk of type 2 diabetes, strokes, dementia, cancer and a lifetime on medication. Close to a quarter of adults in Australia and New Zealand now have raised blood sugar levels or are at risk of developing diabetes â€“ and most donâ€™t know it.', '', '0.000', 2500, 5, '1623090600_8 Week.jpg', '2021-06-08 00:00:35', 41),
(11, 'Physics Practical - Part 2', '9789555258029', '10', 'Tharusha Lasith', 'Tharusha Lasith', 'Text Book for GCE(A/L)', '', '0.000', 900, 20, '1623091080_download (1).jpg', '2021-06-08 00:08:21', 17),
(12, '2009 Bahuwarana Viwaranaya', '9780198497848', '10', 'Prof. SRD Rosa', 'Sarasavi Publishers', 'Advanced Level 2009 Past paper', '', '0.200', 275, 5, '1623091560_Rosa 2009.jpg', '2021-06-08 00:16:27', 20),
(13, 'BUSINESS ACCOUNTING 2', '8131714112354', '10', 'Frank Wood & Alan Sangster', 'Pearson', 'The 10 th edition of the authors best selling book for students to pass accountancy exams', '', '0.000', 1650, 10, '1623352860_Bussiness Accounting.jpg', '2021-06-10 00:55:27', 49),
(14, 'SAMS TEACH YOURSELF OBJECTIVE C IN 24 HOURS', '9789332539136', '9', '	JESSE FEILER', '	PEARSON EDUCATION ASIA', 'In just 24 sessions of one hour or less, you can master the Objective-C language and start using it to write powerful native applications for even the newest', '', '0.000', 1525, 5, '1623352680_SAMS TEACH YOURSELF OBJECTIVE C IN 24 HOURS.jpg', '2021-06-10 01:14:15', 131),
(15, 'THE GREAT ESCAPE: WOLF GIRL 2', '9781760876357', '12', 'Anh Do, Jeremy Ley', 'A&U Childrens AD', 'I held onto the bars of the truck and howled to my dogs as they fell further and further behind.\r\nSunrise, Brutus, Zip, Nosey and Tiny all ran as hard as they could, but there was no way they could keep up...\r\n\r\nAt first, Gwen is overjoyed to see another human after four years alone in the wild.\r\n\r\nBut all that changes when she is thrown into the back of a van and stolen away to a prison camp.', '', '0.000', 3100, 0, '1623340680_ImageHandler.jpg', '2021-06-10 14:06:11', 31),
(16, 'EDUCATION', '9781504302494', '12', 'Paul Donovan', 'Balboa Press Australia', 'n short stories interspersed with diverse characters, Paul Donovan delves into the intricacies of modern relationships, religion, and passions. John Moore works within the world of education where he has finally secured a leadership position. But as rumors begin to circulate of a teacher restructuring, John-who is fueled by his romantic intentions toward another teacher-feels compelled to do everything in his power to stop it. After losing his job, Simon is diligently pursuing a master degree.', '', '0.000', 4800, 0, '1623340440_Education.jpg', '2021-06-10 14:14:19', 50),
(17, 'BLUEY: THE POOL', '9781761040849', '12', 'Bluey', 'Penguin Australia Pty Ltd', 'Bluey and Bingo head to the pool with Dad. What could go wrong? A gorgeous board book for kids of all ages.\r\n\r\nBluey has been a phenomenal success since airing on ABC KIDS in October 2018, amassing legions of dedicated fans and hugely popular ranges of books, toys, clothes, games and more. It holds the coveted position of being the most watched program ever on ABC iView, with over 260 million plays for Series One, and is the winner of an International Emmy for Most Outstanding Childrens Programme.', '', '0.000', 2900, 10, '1623340380_Bluey.jpg', '2021-06-10 14:31:51', 37),
(18, 'BLUEY: BINGO', '9781761041143', '12', 'Bluey', 'Penguin Australia Pty Ltd', 'With Bluey away for the day, can Bingo find a way to play by herself? A board book with a special puzzle surprise.\r\n\r\nBluey has been a phenomenal success since airing on ABC KIDS in October 2018, amassing legions of dedicated fans and hugely popular ranges of books, toys, clothes, games and more. It holds the coveted position of being the most watched program ever on ABC iView, with over 260 million plays for Series One, and is the winner of an International Emmy for Most Outstanding Childrens Programme.', '', '0.000', 1900, 10, '1623340380_Bingo.jpg', '2021-06-10 14:35:09', 29),
(19, 'BOSTON MEDICAL POLICE', '9781176148444', '15', 'Boston Medical Association, Boston Medical Library', 'Creative Media Partners, LLC', 'This is a reproduction of a book published before 1923. This book may have occasional imperfections\r\nsuch as missing or blurred pages, poor pictures, errant marks, etc. that were either part of the original artifact,\r\nor were introduced by the scanning process. We believe this work is culturally important, and despite the imperfections,\r\nhave elected to bring it back into print as part of our continuing commitment to the preservation of printed works\r\nworldwide. We appreciate your understanding of the imperfections in the preservation process, and hope you enjoy this valuable book.', '', '0.000', 7500, 15, '1623340440_Medical.jpg', '2021-06-10 14:42:17', 48),
(20, 'Medical Medium Liver Rescue', '9781401954406', '15', 'Anthony William', 'Hay House Inc', 'Medical Medium Liver Rescue offers the answers you should have had all along. With his signature compassion, Anthony William, the Medical Medium, shares unparalleled insights into undiscovered functions of our life-saving livers, explains whats behind dozens of health issues that hold us back, and offers detailed guidance on how to move forward so we can live our best lives.', '', '0.000', 900, 0, '1623340500_Liver.jpg', '2021-06-10 14:48:17', 131),
(21, 'Medical Billing Training', '9781072920380', '15', 'Medical Billing Experts', 'Amazon Digital Services LLC - Kdp Print Us', 'This is a great Medical Billing and Collections Training Claim Status Checklist Workbook for those that are billers, collectors, coding, billing students, medical billing managers, office staff and medical billing teachers and trainers. This is a great tool, training material, and study guide to have on your billing staffs desks while they are training and making phone calls to medical insurance carriers for claim statuses.', '', '0.000', 22500, 0, '1623340560_billing.jpg', '2021-06-10 15:03:03', 41),
(22, 'Guide to Covid-19: Understanding COVID-19', '9781644945049', '15', 'Douglas Hustad', 'North Star Editions', 'In late 2019, health officials noticed a new disease spreading in Wuhan, China. They named it COVID-19. Within a few months, it became a pandemic that dramatically changed life for nearly everyone on Earth. Millions of people became sick, and hundreds of thousands died. Leaders ordered whole states and countries to stay home to slow the diseases spread. Companies closed or went out of business. Meanwhile, health-care workers on the front lines saved lives and raced to find treatments. In the Core Library Guide to COVID-19, readers will learn about the disease, how it spread across the globe, and the ways it has changed society.', '', '0.000', 2800, 10, '1623340560_Covid 19.jpg', '2021-06-10 17:43:03', 44),
(23, ' Covid-19', '9781780724614', '15', 'Dr Michael Mosley', 'Short Books Ltd', 'What you need to know about the Coronavirus and the race for the vaccine.', '20 *18*2', '0.200', 4300, 20, '1623339900_Covid 19.jpg', '2021-06-10 17:49:39', 216),
(24, 'Excel Basic Skills Workbooks: Science and Technology Years 5â€“6', '9781740200455', '12', 'Peter Clutterbuck', 'Pascal Press', 'Get the Results You Want withthis range of Excel workbooks, study guides and text books that have helped students excel in their studies for over 20 years. Written by experienced educators to support the Australian Curriculum, this range caters to preschool, primary school, high school and tertiary students. The books in our home study range come highly recommended by teachers and are used in many schools.', '', '0.000', 3000, 10, '1623340620_Science and tech.jpg', '2021-06-10 17:58:36', 40),
(25, 'Excel Basic Skills Core Books: English Year 3', '9781741256116', '12', 'Donna Gibbs', 'Donna Gibbs', 'The aim of this book is to build basic skills in reading, comprehension, spelling, vocabulary, grammar and punctuation. The format of each unit is the same so that students become familiar with the requirements of each question, which become progressively more difficult as students work through the book.', '', '0.000', 3000, 0, '1623340680_English.jpg', '2021-06-10 18:01:41', 39),
(26, 'Beginning Android Development', '9781502395221', '9', 'Pawprints Learning Technologies', 'Amazon Digital Services LLC - Kdp Print Us', 'Visit us at www.programminghq.com for more exciting programming stuff! Create amazing Android applications today! The rapid rise of the Android OS offers app developers one of the largest platforms available, and this easy-to-follow guide walks you through the development process step by step. Android programming experts teach you how to download the SDK, get Eclipse up and running, code Android applications, submit your app to the Google Play Store and share your finished Android apps with the world.', '', '0.000', 9200, 0, '1623339960_Android.jpg', '2021-06-10 18:09:40', 34),
(28, 'Concepts and Semantics of Programming Languages 1', '9781786305305', '9', 'Therese Hardin, Mathieu Jaume, Francois Pessaux, Veronique Viguie Donzeau-Gouge', 'Wiley', 'This book - the first of two volumes - explores the syntactical constructs of the most common programming languages, and sheds a mathematical light on their semantics, while also providing an accurate presentation of the material aspects that interfere with coding.\r\nConcepts and Semantics of Programming Languages 1 is dedicated to functional and imperative features.', '', '0.000', 48000, 10, '1623340020_concepts.jpg', '2021-06-10 18:19:09', 31),
(29, 'Computer-Hardware Evaluation of Mathematical Functions', '9781783268603', '13', 'Amos Omondi', 'World Scientific Publishing Co Pte Ltd', 'Computer-Hardware Evaluation of Mathematical Functions provides a thorough up-to-date understanding of the methods used in computer hardware for the evaluation of mathematical functions: reciprocals, square-roots, exponentials, logarithms, trigonometric functions, hyperbolic functions, etc. It discusses how the methods are derived, how they work, and how well they work. The methods are divided into four core themes', '', '0.000', 36000, 0, '1623340020_Comp Hardware.jpg', '2021-06-10 18:26:14', 39),
(30, ' Laptop Repair Complete Guide; Including Motherboard Component Level Repair!', '9781468096521', '13,9', 'Garry Romaneo', 'Amazon Digital Services LLC - Kdp Print Us', 'This book will educate you on the Correct Process of Repairing The Entire Laptop, Including and concentrating more on Motherboard Repair Instruction, Screen Repairing, Component Level Diagnosing and Repairing. This is the 3rd Book Released By Author Garry Romaneo, The Worlds Leading Laptop Repair Technician, Author, and Consultant. The book will take you through the laptops disassembly process, Explaining in detail how to disassemble all laptops. You will then be taught all about Liquid Spills to Laptops. What to do, What not to do, How to Remove Liquid and How To Repair Any Damage from Liquid to parts or components.', '', '0.000', 19750, 0, '1623339900_Laptop.jpg', '2021-06-10 19:29:48', 39),
(31, 'ATAR Notes NSW Year 12 Biology Notes', '9781925534726', '10', 'Madeleine Wainwright', 'Madeleine Wainwright', 'Our Biology Year 12 Notes contain the most effective summary of all four modules in the syllabus. With detailed coverage of every syllabus dot point, this book has done all the hard work for you! Though Biology is a tough subject with some complex theory (and a LOT of content), the clear explanations and examples in these pages will make this book your Bio-bible!', '', '0.000', 5500, 10, '1623349080_Biology.jpg', '2021-06-10 23:48:42', 39),
(32, 'Mathematics', '9781731862143', '10', 'National Learning Corporation', 'Chicago Review Press Inc DBA Independ Pub Grp', 'The Mathematics: Calculus Ab/Bc Passbook(R) prepares you for your test by allowing you to take practice exams in the subjects you need to study. It provides hundreds of questions and answers in the areas that will likely be covered on your upcoming exam.', '', '0.000', 12500, 10, '1623349620_maths.jpg', '2021-06-10 23:57:37', 31),
(33, 'Mathematics', '9781497391550', '10', 'Mukesh Grover', 'CreateSpace Independent Publishing Platform', 'Mathematics expresses itself everywhere, in almost every facet of life - in nature all around us, and in the technologies in our hands. Mathematics is the language of science and engineering - describing our understanding of all that we observe. Mathematics in everyday life refers to the way humans use math to complete certain tasks throughout the day. ', '', '0.000', 13200, 0, '1623350220_maths2.jpg', '2021-06-11 00:07:11', 41),
(34, 'Vocational Education', '9781177079440', '11', 'Anonymous', 'BiblioBazaar', 'Vocational Education', '', '0.000', 12500, 10, '1623350760_Vocational.jpg', '2021-06-11 00:16:33', 31),
(35, 'Handbook of Vocational Education and Training: Developments in the Changing World of Work 1st ed. 2019 Edition', '9783319945316', '11', ' Rebecca Suart', 'Springer', 'This handbook brings together and promotes research on the area of vocational education and training (VET). It analyzes current and future economic and labor market trends and relates these to likely implications for vocational education and training. It questions how VET engages with the growing power of human development approaches and with the sustainable development agenda. Equity and inclusion are discussed in a range of ways by the authors and the consideration of the construction of these terms is an important element of the handbook. It further addresses both the overall notion of system reform, at different scales, and what is known about particular technologies of systems reform across a variety of settings. Vocational learning and VET teacher/trainer education are discussed from a comparative perspective.', '', '0.000', 5500, 5, '1623391620_Vocational Education.jpg', '2021-06-11 11:37:17', 40),
(36, 'OVERVIEW OF TECHNICAL AND VOCATIONAL EDUCATION IN LATIN AMERICA: Technical Vocational Training System in Brazil, Colombia, Argentina, Chile and Mexico', '9786202725019', '11', ' Daniel Bartolome Llorente', 'Our Knowledge Publishing', 'echnical and/or professional education should be one of the pillars of the education system of any country, understanding it as an education that not only tries to train the person to perform a specific job. With it, all the capacities of a student can be developed, both technical and social and personal, generating professionals with a broader profile that can be adapted to the circumstances.This book makes a comparative analysis of the technical and/or professional training of five Latin American countries: Brazil, Colombia, Argentina, Chile and Mexico.', '', '0.000', 8700, 15, '1623392040_vocational Latin America.jpg', '2021-06-11 11:44:13', 32),
(37, 'Electrical Education Guide: (Design, Wiring, and Installation)', '9780999636909', '11', 'Alexander M Cagnola', 'Texas Trade Institute, LLC', 'The information found within this text should provides more information needed for education, training, and testing in the electrical industry than any other publication to date. \r\n\r\nEvery procedure needed to completely install electrical systems from start to finish in residential and commercial structures can be found with full color illustrations in this work. Years of research, and over 50 combined years of electrical knowledge as master electricians were used in the making of this publication.', '', '0.000', 7600, 10, '1623393060_Electricity.jpg', '2021-06-11 12:01:38', 50),
(38, 'Pulp Friction (A Cider Shop Mystery)', '9781496723499', '14', 'Julie Anne Lindsey', 'Kensington', 'Thanks to Winnies new cider shop, Smythe Orchards is out of the red and folks can get their fix of the produce and other delectable products they love all year round. The locals are even booking the shop for events, including a June wedding! Winnie couldnt be happier to see the barn filled to the rafters for the big bashâ€”until her doting ex, Hank, is caught in a heated argument with the groom. Winnie plans to scold Hank after the party, but spots him running off instead. And when the groom turns up dead, apparently hit by the honeymoon getaway car, Hank is the main suspect. Now Hank is on the lam', '', '0.000', 4500, 5, '1623394080_Pulp.jpg', '2021-06-11 12:18:32', 51),
(39, 'Friction Ridge Skin: Comparison and Identification of Fingerprints (Practical Aspects of Criminal and Forensic Investigations', '9780849395024', '14', 'James F. Cowger', 'CRC Press', 'Here is a complete guide to the collection, classification, and comparison of friction skin prints and the determination of identity and nonidentity. It discusses: the cause and significance of variations in prints; the importance of class characteristics in print; the application of probability in decision making; and photographic techniques and considerations', '', '0.000', 3800, 5, '1623394440_Rige Skin.jpg', '2021-06-11 12:24:05', 51),
(40, 'Modern Computer Architecture and Organization: Learn x86, ARM, and RISC-V architectures and the design of smartphones, PCs, and cloud servers', '9781838984397', '13', 'Jim Ledin', 'Packt Publishing', 'A no-nonsense, practical guide to current and future processor and computer architectures, enabling you to design computer systems and develop better software applications across a variety of domains\r\n\r\nKey Features\r\nUnderstand digital circuitry with the help of transistors, logic gates, and sequential logic\r\nExamine the architecture and instruction sets of x86, x64, ARM, and RISC-V processors\r\nExplore the architecture of modern devices such as the iPhone X and high-performance gaming PCs', '', '0.000', 6000, 10, '1623394920_Modern Com.jpg', '2021-06-11 12:32:26', 32),
(41, 'Advanced Physics (Advanced Sciences) ', '9780198392927', '10', ' Steve Adams', 'Oxford', 'Advanced Physics provides comprehensive coverage of all the content you need to know; this revised and updated second edition will remain relevant even when specifications change. This indispensable guide takes a thorough and engaging approach to AS and A Level Physics.', '12x3x12', '0.255', 8500, 0, '1625836380_Tharusha UOCqwq.jpg', '2021-07-09 18:43:26', 49),
(44, 'MS DOS', '1234567', '9', 'Padmal Harshana', 'Sagarika Publications', 'Welcome to DOS', '20 inch', '0.200', 740, 25, '1630165500_JAAI-Certificate.jpg', '2021-08-28 21:15:46', 48),
(45, 'Windows 7', '1234321', '9', 'Padmal Harshana', 'Sagarika Publications', 'Welcome to Windows', '20 inch', '0.200', 520, 10, '1630166640_JAAI-Certificate2.jpg', '2021-08-28 21:34:49', 139);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `book_id` int(30) NOT NULL,
  `qty` int(30) NOT NULL,
  `price` float NOT NULL,
  `discount_per` int(3) NOT NULL,
  `customer_id` int(30) NOT NULL,
  `transport_fee` int(20) NOT NULL,
  `cart_create_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=190 ;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`) VALUES
(9, 'Computer Software', 'Information Technology Software Books'),
(10, 'Secondary Education', 'Secondary Education Text Books'),
(11, 'Vocational Education', 'Vocational Education Books'),
(12, 'Primary Education Books', 'Primary Education Books'),
(13, 'Computer Hardware', 'Information Technology Hardware Books'),
(14, 'Fiction', 'Fiction books'),
(15, 'Medical', 'Medical Books');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `lname` varchar(100) NOT NULL,
  `str_no` varchar(50) NOT NULL,
  `str_name` varchar(150) NOT NULL,
  `city` varchar(150) NOT NULL,
  `country` varchar(150) NOT NULL,
  `postal_code` varchar(50) NOT NULL,
  `age` varchar(20) NOT NULL,
  `category_ids` text NOT NULL,
  `contact` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` text NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=45 ;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `lname`, `str_no`, `str_name`, `city`, `country`, `postal_code`, `age`, `category_ids`, `contact`, `email`, `password`, `date_created`) VALUES
(10, 'mahesh', 'maduranga', '55', 'athurugiriya', 'Colombo', 'Sri Lanka', '12548', '23', '9, 15', '0147854878', 'mahesh@gmail.com', '7cb323203b1306810d65271d8e9228ef', '2021-06-07 22:25:21'),
(9, 'thilak', 'bandara', '45', 'dambagalla', 'Moneragala', 'Sri Lanka', '4587', '25', '', '01745875', 'thilak@gmail.com', 'acf323ac4b3c1f9d098b16ba91172f2f', '2021-06-07 21:31:17'),
(8, 'Manel', 'perera', '264', 'Malwana', 'Biyagama', 'Sri Lanka', '25487', '79', '', '0115450801', 'manel@gmail.com', '3c32f0377866618ff9e547fe5bea8687', '2021-06-07 19:58:25'),
(11, 'Lasith', 'Dissanayake', '110/1', 'Thimbirigasyaya road', 'colombo 5', 'Sri Lanka', '100500', '41', '', '0714406767', 'lasith@gmail.com', 'f3cdc14175d5bdcefde89f567848dd27', '2021-06-08 15:22:58'),
(12, 'darshika', 'perera', '264', 'Biyagama', 'Gampaha', 'Sri Lanka', '25487', '31', '', '01718675538', 'darshika@gmail.com', '2b88f18e7b1381f5c10e4f8538cfce3e', '2021-06-10 12:12:49'),
(13, 'Pamitha', 'Savunjith', '265', 'Polhena road', 'Gampaha', 'Sri Lanka', '124578', '28', '', '0112450801', 'pamitha@gmail.com', '2b88f18e7b1381f5c10e4f8538cfce3e', '2021-06-10 20:56:00'),
(14, 'tharusha', 'lasanth', '176', 'Walpita', 'Batawala', 'Sri Laka', '01478', '41', '', '0714406767', 'tharusha@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', '2021-06-16 22:47:03'),
(15, 'Samantha', 'Aluthdenya', '110/1', 'Dekatana', 'Gampaha', 'Sri Lanka', '112200', '39', '', '01745875', 'samantha@gmail.com', '750436ab90e64eb4397bc97f258cebd5', '2021-06-25 08:15:40'),
(16, 'Thanuja', 'Perera', '245', 'Walagama', 'Wattala', 'Sri Lanka', '254125', '45', '', '01745875', 'thanuja@gmail.com', 'ed07503cd939f0b71adb996719a91e12', '2021-06-25 09:10:15'),
(17, 'Rohan', 'Priyanga', '45', 'Meegahapitiya', 'Colombo', 'Sri Lanka', '222111', '25', '', '0457855545', 'rohan@gmail.com', 'aeae5b2f900e84d784a0f0111e650835', '2021-06-25 09:34:38'),
(18, 'samira', 'Dananjaya', '25', 'Kiribathgoda', 'Gampaha', 'Sri Lanka', '225415', '31', '', '017474878', 'samira@gmail.com', '3f3b0950f371a42d6b2cd8508de77f1d', '2021-06-25 10:34:30'),
(19, 'David', 'Perera', '264/1', 'Polhena Road', 'Malwana', 'Sri LAnka', '254412', '80', '', '0112450801', 'david@gmail.com', '55fc5b709962876903785fd64a6961e5', '2021-06-25 19:50:32'),
(20, 'Wasantha', 'Kumara', '31', 'Rukmalgama', 'Kottawa', 'Sri Lanka', '5548700', '45', '', '071440879', 'wasantha@gmail.com', 'b1e92e1c84aaef98ca8cdecf6f704afd', '2021-04-25 20:27:46'),
(21, 'Pasindu', 'Konara', '8', 'Walpita', 'Batawala', 'Sri Lanka', '22548', '40', '', '011477878', 'pasindu@gmail.com', '695f75582757373a94dad53f0203cfca', '2021-06-25 21:58:04'),
(22, 'Keerthi', 'Perera', '100', 'Polhena Road', 'Malwana', 'Sri Lanka', '225487', '28', '', '0714406768', 'keerthi@gmail.com', 'b599a42675ba2cc5b2d4b146684a72af', '2021-06-26 15:45:57'),
(23, 'Rasika', 'Koswatta', '45/3', 'Gall Road', 'Panadura', 'Sri Lanka', '225487', '42', '', '0174448885', 'rasika@gmail.com', 'cac182a5e3076bd18c38335b57b3bd07', '2021-06-27 11:05:58'),
(24, 'Asiri', 'Bandara', '458', 'Daham mawatha', 'Homagama', 'Sri Lanka', '221140', '42', '', '0724406767', 'asiri@gmail.com', '572f6f102bcbe3b0bf2086a967edeb8f', '2021-06-27 17:42:16'),
(25, 'Karunarathne', 'Konara', '578', 'Ruwalwela', 'Moneragala', 'Sri Lanka', '225587', '46', '', '0740254852', 'karunarathne@gmail.com', 'dd00279ad93595236e86afaea7ad287e', '2021-06-27 20:38:42'),
(26, 'Karunaratha', 'Konara', '587', 'Udawelwatiya', 'Ruwalwela', 'Sri Lanka', '1125484', '45', '', '0774446767', 'konara1@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', '2021-07-10 11:04:34'),
(27, 'Tharaka', 'Dissanayake', '110/2', 'Galavila', 'Homagama', 'Sri Lanka', '254871', '48', '', '0713306767', 'tharaka@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', '2021-07-10 14:23:12'),
(28, 'Padmal', 'Harshana', '1234', 'Pasyala Road', 'Gampaha', 'Sri Lanka', '123345', '41', '', '0714465870', 'padmal@gmail.com', 'a99d2b1828114b838f1d04e4bdf6cf8a', '2021-07-12 01:21:59'),
(29, 'Sagarika', 'Wickramasinghe', '123', 'Sudunelum Mawatha', 'Gampaha', 'England', '112223334', '99', '', '112223334', 'sagarika@gmail.com', '5839b3663024638f9597121cc00556cd', '2021-07-13 20:49:58'),
(30, 'Sagarika', 'Ltd', '120', '123', 'Gampaha', 'Sri Lanka', '11000', '40', '', '0714465870', 'helanet@hala.com', '8e0fffd01ed68a85776cde093a965176', '2021-07-13 21:21:03'),
(31, 'Sagarika', 'Ltd', '120', '123', 'Gampaha', 'Sri Lanka', '11000', '40', '', '0714465870', 'helanet@halaaa.com', '8e0fffd01ed68a85776cde093a965176', '2021-07-13 21:21:16'),
(32, 'Hela', 'Ltd', '120', '123', 'Gampaha', 'Sri Lanka', '11000', '40', '', '0714465870', 'sumali@gmail.com', '1b19a9e4d1f6fe55dee0bd4058ab652b', '2021-07-13 21:21:54'),
(33, 'Sasen', 'Dulnitha', '123', 'Haramanis', 'Makkanigoda', 'Sri Lanka', '1123', '12', '', '0714465870', 'sasen@gmail.com', '7cc3a4ed032a99c12ba0cceae6c86134', '2021-07-13 23:07:33'),
(34, 'Vidun', 'Nethmira', '123', '4555', 'Gampaha', 'Lanka', '1231', '78', '', '0714465870', 'helanet@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '2021-07-13 23:47:17'),
(35, 'Vijepala', 'Liyanage', '123', 'Haramanis', 'Makkanigoda', 'Sri Lanka', '1123', '81', '', '0714465879', 'vijepala@gmail.com', 'a4c578308fc340591f4b2a83509dfaf7', '2021-07-13 23:48:44'),
(36, 'Soma ', 'Wickramasinghe', '123', 'Haramanis', 'Makkanigoda', 'Sri Lanka', '1123', '73', '', '123456779', 'soma@gmail.com', '15a00ab33070d69d3ec3f03a9222034b', '2021-07-13 23:54:10'),
(37, 'Nanda', 'Jayalath', '123', 'Haramanis', 'Makkanigoda', 'Sri Lanka', '1123', '81', '', '0714465879', 'nanda@gmail.com', '859a37720c27b9f70e11b79bab9318fe', '2021-07-13 23:57:06'),
(38, 'kota', 'katta', '123', 'Haramanis', 'Makkanigoda', 'Sri Lanka', '1123', '4', '9, 15', '071446876', 'kota@katta.com', '03b6d9a6e735bb09bba71f4d24b2c312', '2021-07-14 00:07:16'),
(39, 'Tharusha', 'Dissanayake', '110/A', 'Thimbirigasyaya rd.', 'Colombo 05', 'Sri Lanka', '005000', '42', '9, 10', '0714406767', 'tlasith@gmail.com', 'bdcc8f56a0753eec8458dd67430fbef3', '2021-09-04 23:09:50'),
(40, 'nishantha', 'sampath', '10', 'Kolonnawa', 'colombo 12', 'Sri lanka', '00120000', '40', '9, 15', '0714406969', 'nishantha@gmail.com', '81a177dc6b65a514e8af9667508c0887', '2021-09-09 17:08:00'),
(41, 'Thilan', 'Samaraweera', '114', 'Railway avenue', 'Nugegoda', 'Sri Lanka', '012554', '42', '12', '0714408899', 'thilan@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', '2021-09-09 19:10:44'),
(42, 'darshika', 'perera', '164/1/A', 'Polhena Road', 'Malwana', 'Sri Lanka', '0044784', '38', '12, 11', '0718675538', 'darshika2@gmail.com', 'a91c8c0b3ec4598ced221fe6484dc3e2', '2021-09-12 14:29:39'),
(44, 'asanka', 'perera', '110/5', 'Polhena rd.', 'Biyagama', 'Sri Lanka', '0011454', '40', '13, 9, 14, 15, 12', '0714455781', 'asanka@gmail.com', 'd6fba07ea637c7183498d6147979a96e', '2021-09-20 04:57:15');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `customer_id` int(30) NOT NULL,
  `address` text NOT NULL,
  `pay_type` int(1) NOT NULL,
  `total_amount` float NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `delivery_ref_no` varchar(100) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=116 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_id`, `address`, `pay_type`, `total_amount`, `status`, `delivery_ref_no`, `date_created`) VALUES
(12, 19, '264/1, Polhena Road, Malwana, Sri LAnka, 254412', 0, 0, 1, '', '2021-06-25 23:19:22'),
(13, 19, '264/1, Polhena Road, Malwana, Sri LAnka, 254412', 0, 0, 1, '', '2021-06-25 23:20:01'),
(14, 10, '55, athurugiriya, Colombo, Sri Lanka, 12548', 0, 0, 2, '7833500', '2019-01-26 00:00:16'),
(15, 10, '55, athurugiriya, Colombo, Sri Lanka, 12548', 0, 0, 2, '4545685', '2019-01-26 00:00:42'),
(16, 10, '55, athurugiriya, Colombo, Sri Lanka, 12548', 0, 0, 2, '4545698', '2019-01-26 00:01:24'),
(17, 14, '176, Walpita, Batawala, Sri Laka, 01478', 0, 0, 1, '', '2019-02-22 00:04:28'),
(18, 14, '176, Walpita, Batawala, Sri Laka, 01478', 0, 0, 1, '', '2019-02-22 00:04:53'),
(19, 14, '176, Walpita, Batawala, Sri Laka, 01478', 0, 0, 1, '', '2019-02-22 00:05:28'),
(20, 10, '55, athurugiriya, Colombo, Sri Lanka, 12548', 0, 0, 1, '', '2019-02-22 00:06:50'),
(21, 10, '55, athurugiriya, Colombo, Sri Lanka, 12548', 0, 0, 1, '', '2019-02-22 00:07:17'),
(22, 10, '55, athurugiriya, Colombo, Sri Lanka, 12548', 0, 0, 1, '', '2019-02-22 00:08:43'),
(23, 12, '264, Biyagama, Gampaha, Sri Lanka, 25487', 0, 0, 1, '', '2019-03-13 00:14:04'),
(24, 12, '264, Biyagama, Gampaha, Sri Lanka, 25487', 0, 0, 1, '', '2019-03-13 00:14:27'),
(25, 12, '264, Biyagama, Gampaha, Sri Lanka, 25487', 0, 0, 1, '', '2019-03-13 00:15:00'),
(26, 10, '55, athurugiriya, Colombo, Sri Lanka, 12548', 0, 0, 1, '', '2019-03-13 00:15:55'),
(27, 10, '55, athurugiriya, Colombo, Sri Lanka, 12548', 0, 0, 1, '', '2019-03-13 00:16:53'),
(28, 9, '45, dambagalla, Moneragala, Sri Lanka, 4587', 0, 0, 1, '', '2019-04-10 00:21:54'),
(29, 9, '45, dambagalla, Moneragala, Sri Lanka, 4587', 0, 0, 1, '', '2019-04-10 00:22:25'),
(30, 9, '45, dambagalla, Moneragala, Sri Lanka, 4587', 0, 0, 1, '', '2019-04-10 00:22:54'),
(31, 9, '45, dambagalla, Moneragala, Sri Lanka, 4587', 0, 0, 1, '', '2019-04-10 00:23:23'),
(32, 12, '264, Biyagama, Gampaha, Sri Lanka, 25487', 0, 0, 1, '', '2019-05-03 00:26:51'),
(33, 12, '264, Biyagama, Gampaha, Sri Lanka, 25487', 0, 0, 1, '', '2019-05-03 00:27:22'),
(34, 12, '264, Biyagama, Gampaha, Sri Lanka, 25487', 0, 0, 1, '', '2019-05-03 00:27:57'),
(35, 14, '176, Walpita, Batawala, Sri Laka, 01478', 0, 0, 1, '', '2019-05-03 00:29:33'),
(36, 14, '176, Walpita, Batawala, Sri Laka, 01478', 0, 0, 1, '', '2019-05-03 00:30:06'),
(37, 8, '264, Malwana, Biyagama, Sri Lanka, 25487', 0, 0, 1, '', '2019-06-26 00:35:00'),
(38, 8, '264, Malwana, Biyagama, Sri Lanka, 25487', 0, 0, 1, '', '2019-06-26 00:35:37'),
(39, 8, '264, Malwana, Biyagama, Sri Lanka, 25487', 0, 0, 1, '', '2019-06-26 00:36:06'),
(40, 8, '264, Malwana, Biyagama, Sri Lanka, 25487', 0, 0, 1, '', '2019-06-26 00:36:43'),
(46, 14, '176, Walpita, Batawala, Sri Laka, 01478', 0, 0, 1, '', '2019-07-02 00:56:25'),
(47, 22, '100, Polhena Road, Malwana, Sri Lanka, 225487', 0, 0, 1, '', '2021-06-26 15:46:40'),
(48, 22, '100, Polhena Road, Malwana, Sri Lanka, 225487', 0, 0, 1, '', '2021-06-26 15:47:31'),
(49, 11, '110/1, Thimbirigasyaya road, colombo 5, Sri Lanka, 100500', 0, 0, 1, '', '2021-06-26 20:36:08'),
(50, 11, '110/1, Thimbirigasyaya road, colombo 5, Sri Lanka, 100500', 0, 0, 1, '', '2021-06-26 22:31:49'),
(51, 23, '45/3, Gall Road, Panadura, Sri Lanka, 225487', 0, 0, 1, '', '2021-06-27 11:06:48'),
(52, 14, '176, Walpita, Batawala, Sri Laka, 01478', 0, 0, 1, '', '2021-06-30 19:31:06'),
(53, 14, '176, Walpita, Batawala, Sri Laka, 01478', 0, 0, 1, '', '2021-07-09 23:43:21'),
(54, 28, '1234, Pasyala Road, Gampaha, Sri Lanka, 123345', 0, 0, 1, '', '2021-07-17 01:58:52'),
(55, 28, '1234, Pasyala Road, Gampaha, Sri Lanka, 123345', 0, 0, 1, '7833501', '2021-08-28 20:28:39'),
(57, 28, '1234, Pasyala Road, Gampaha, Sri Lanka, 123345', 0, 0, 1, '3333', '2021-08-28 23:38:32'),
(58, 28, '1234, Pasyala Road, Makkanigoda', 0, 0, 1, '7833502', '2021-08-29 02:04:46'),
(60, 28, 'Ruggahavila', 0, 0, 1, '7833504', '2021-08-29 02:11:45'),
(61, 28, 'Gampaha', 0, 0, 1, '7833505', '2021-08-29 02:12:57'),
(62, 28, 'Pasyala Road, Gampaha, Sri Lanka, 123345', 0, 0, 1, '120076', '2021-08-29 02:33:32'),
(63, 28, '1234', 1, 0, 1, '1234567810CD', '2021-08-29 02:35:15'),
(64, 13, '265, Polhena road, Gampaha, Sri Lanka, 124578', 1, 0, 1, '7833505', '2021-08-29 19:33:45'),
(65, 8, '264, Malwana, Biyagama, Sri Lanka, 25487', 1, 0, 2, '7833506', '2021-09-04 22:54:34'),
(67, 8, '264, Malwana, Biyagama, Sri Lanka, 25487', 0, 0, 1, '5544121', '2021-09-05 23:49:47'),
(68, 13, '265, Polhena road, Gampaha, Sri Lanka, 124578', 0, 0, 1, '5522142', '2021-09-06 12:34:01'),
(69, 13, '', 1, 0, 1, '7833507', '2021-09-06 12:34:43'),
(70, 13, '265, Polhena road, Gampaha, Sri Lanka, 124578', 0, 0, 1, '7833508', '2021-09-06 14:40:17'),
(71, 13, '', 1, 0, 1, '5522413', '2021-09-06 14:41:20'),
(72, 10, '55, athurugiriya, Colombo, Sri Lanka, 12548', 0, 0, 1, '5522414', '2021-09-06 14:49:01'),
(73, 10, '55, athurugiriya, Colombo, Sri Lanka, 12548', 0, 0, 2, '7898558', '2021-09-06 15:20:43'),
(74, 10, '', 1, 0, 2, '8455895', '2021-09-06 15:21:26'),
(75, 10, '55, athurugiriya, Sri Lanka, 12548', 1, 0, 2, '7845884 10 days delay', '2021-09-06 15:28:01'),
(76, 10, '55, athurugiriya, Colombo, Sri Lanka, 12548', 1, 0, 2, '', '2021-09-06 15:30:30'),
(77, 10, '55, athurugiriya, Colombo, Sri Lanka, 12548', 0, 0, 2, '10 days delay', '2021-09-06 15:31:59'),
(78, 10, '55, athurugiriya, Colombo, Sri Lanka, 12548', 1, 0, 2, '', '2021-09-08 19:01:50'),
(79, 8, '264, Malwana, Biyagama, Sri Lanka, 25487', 0, 0, 2, '', '2021-09-10 19:31:31'),
(81, 8, '264, Malwana, Biyagama, Sri Lanka, 25487', 0, 0, 2, '', '2021-09-10 20:19:38'),
(82, 10, '55, athurugiriya, Colombo, Sri Lanka, 12548', 0, 0, 2, '8784902', '2021-09-11 13:13:34'),
(83, 13, '265, Polhena road, Gampaha, Sri Lanka, 124578', 0, 0, 2, '8784902', '2021-09-11 19:11:07'),
(84, 42, '164/1/A, Polhena Road, Malwana, Sri Lanka, 0044784', 0, 0, 1, '8684907', '2021-09-12 14:42:41'),
(85, 10, '55, athurugiriya, Colombo, Sri Lanka, 12548', 0, 0, 2, '8784901', '2021-09-15 02:40:56'),
(86, 10, '55, athurugiriya, Colombo, Sri Lanka, 12548', 0, 0, 2, '8745879', '2021-09-15 03:00:17'),
(87, 8, '264, Malwana, Biyagama, Sri Lanka, 25487', 0, 0, 2, '8784900', '2021-09-16 16:11:03'),
(88, 44, '110/5, Polhena rd., Biyagama, Sri Lanka, 0011454', 0, 0, 1, '8784903', '2021-09-20 05:02:39'),
(89, 44, '110/5, Polhena rd., Biyagama, Sri Lanka, 0011454', 0, 0, 1, '', '2021-09-20 05:09:26'),
(90, 8, '264, Malwana, Biyagama, Sri Lanka, 25487', 0, 0, 1, '8581907', '2021-09-21 18:30:17'),
(91, 8, '264, Malwana, Biyagama, Sri Lanka, 25487', 1, 0, 1, '8784711', '2021-09-21 18:31:57'),
(92, 10, '55, athurugiriya, Colombo, Sri Lanka, 12548', 0, 0, 2, '8784905', '2021-09-21 20:10:19'),
(93, 39, '110/A, Thimbirigasyaya rd., Colombo 05, Sri Lanka, 005000', 0, 0, 1, '8784900', '2021-09-24 12:08:56'),
(94, 13, '265, Polhena road, Gampaha, Sri Lanka, 124578', 1, 0, 0, '', '2021-09-24 18:20:08'),
(95, 13, '265, Polhena road, Gampaha, Sri Lanka, 124578', 0, 0, 2, '8784902', '2021-09-25 07:23:53'),
(96, 39, '110/A, Thimbirigasyaya rd., Colombo 05, Sri Lanka, 005000', 0, 0, 1, '8784902', '2021-09-25 10:35:22'),
(97, 39, '110/A, Thimbirigasyaya rd., Colombo 05, Sri Lanka, 005000', 0, 0, 1, '8784901', '2021-09-25 10:35:49'),
(98, 39, '110/A, Thimbirigasyaya rd., Colombo 05, Sri Lanka, 005000', 0, 0, 1, '8784903', '2021-09-25 11:09:06'),
(99, 39, '110/A, Thimbirigasyaya rd., Colombo 05, Sri Lanka, 005000', 0, 0, 1, '8784905', '2021-09-25 11:46:25'),
(100, 39, '110/A, Thimbirigasyaya rd., Colombo 05, Sri Lanka, 005000', 0, 0, 1, '7884120', '2021-09-25 13:59:40'),
(101, 13, '265, Polhena road, Gampaha, Sri Lanka, 124578', 0, 0, 1, '8784907', '2021-10-19 15:31:18'),
(102, 13, '265, Polhena road, Gampaha, Sri Lanka, 124578', 0, 0, 0, '', '2021-10-19 15:42:23'),
(103, 13, '265, Polhena road, Gampaha, Sri Lanka, 124578', 0, 0, 0, '', '2021-10-19 15:43:19'),
(104, 10, '55, athurugiriya, Colombo, Sri Lanka, 12548', 0, 0, 0, '', '2021-11-03 19:46:23'),
(105, 10, '55, athurugiriya, Colombo, Sri Lanka, 12548', 1, 0, 0, '', '2021-11-03 20:42:40'),
(106, 10, '55, athurugiriya, Colombo, Sri Lanka, 12548', 0, 0, 1, '8784911', '2021-11-04 00:20:59'),
(107, 10, '55, athurugiriya, Colombo, Sri Lanka, 12548', 0, 0, 0, '', '2021-11-04 11:43:19'),
(108, 13, '265, Polhena road, Gampaha, Sri Lanka, 124578', 0, 0, 1, '8787907', '2021-11-04 12:08:34'),
(109, 13, '265, Polhena road, Gampaha, Sri Lanka, 124578', 0, 0, 1, '8155448', '2021-11-04 13:05:54'),
(110, 13, '265, Polhena road, Gampaha, Sri Lanka, 124578', 1, 0, 1, '8745448', '2021-11-04 13:11:32'),
(111, 39, '110/A, Thimbirigasyaya rd., Colombo 05, Sri Lanka, 005000', 0, 0, 1, '8745125', '2021-11-06 08:45:00'),
(114, 13, '265, Polhena road, Gampaha, Sri Lanka, 124578', 0, 0, 1, '8784912', '2021-11-06 15:55:12'),
(115, 13, '265, Polhena road, Gampaha, Sri Lanka, 124578', 0, 0, 2, '8784913', '2021-11-13 22:11:03');

-- --------------------------------------------------------

--
-- Table structure for table `order_list`
--

CREATE TABLE IF NOT EXISTS `order_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `order_id` int(30) NOT NULL,
  `book_id` int(30) NOT NULL,
  `qty` int(30) NOT NULL,
  `price` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=145 ;

--
-- Dumping data for table `order_list`
--

INSERT INTO `order_list` (`id`, `order_id`, `book_id`, `qty`, `price`) VALUES
(16, 12, 12, 1, 275),
(17, 13, 40, 2, 6000),
(18, 14, 26, 1, 9200),
(19, 15, 30, 1, 19750),
(20, 16, 11, 2, 900),
(21, 17, 30, 1, 19750),
(22, 18, 29, 1, 36000),
(23, 19, 40, 2, 6000),
(24, 20, 18, 1, 1900),
(25, 21, 17, 1, 2900),
(26, 22, 24, 1, 3000),
(27, 23, 34, 1, 12500),
(28, 24, 23, 1, 4300),
(29, 25, 17, 2, 2900),
(30, 26, 12, 1, 275),
(31, 27, 33, 1, 13200),
(32, 28, 39, 1, 3800),
(33, 29, 38, 1, 4500),
(34, 30, 8, 1, 5250),
(35, 31, 25, 1, 3000),
(36, 32, 12, 1, 275),
(37, 33, 11, 3, 900),
(38, 34, 32, 1, 12500),
(39, 35, 37, 1, 7600),
(40, 36, 11, 1, 900),
(41, 37, 23, 1, 4300),
(42, 38, 21, 1, 22500),
(43, 39, 19, 1, 7500),
(44, 40, 10, 2, 2500),
(50, 46, 23, 1, 4300),
(51, 47, 18, 1, 1900),
(52, 48, 35, 3, 5500),
(53, 49, 23, 1, 4300),
(54, 50, 23, 1, 4300),
(55, 51, 19, 1, 7500),
(56, 52, 7, 1, 2345),
(57, 53, 30, 1, 19750),
(58, 54, 23, 1, 4300),
(59, 54, 30, 2, 19750),
(60, 55, 30, 1, 19750),
(61, 55, 23, 1, 4300),
(62, 57, 23, 1, 4300),
(63, 57, 44, 1, 555),
(64, 58, 23, 1, 4300),
(65, 60, 23, 1, 4300),
(66, 61, 23, 1, 4300),
(67, 62, 44, 2, 555),
(68, 63, 45, 2, 468),
(69, 64, 23, 1, 4300),
(70, 64, 26, 1, 9200),
(71, 65, 30, 2, 19750),
(72, 66, 23, 1, 3440),
(73, 66, 12, 1, 275),
(74, 66, 11, 1, 720),
(75, 67, 24, 1, 3000),
(76, 67, 12, 1, 261.25),
(77, 68, 30, 2, 19750),
(78, 69, 34, 1, 12500),
(79, 70, 16, 1, 4800),
(80, 71, 9, 2, 3250),
(81, 72, 11, 1, 720),
(82, 73, 11, 3, 720),
(83, 74, 23, 1, 3440),
(84, 75, 11, 2, 720),
(85, 76, 31, 2, 5500),
(86, 77, 11, 2, 720),
(87, 78, 17, 1, 2900),
(88, 78, 11, 1, 720),
(89, 79, 9, 1, 3250),
(90, 79, 41, 8, 8500),
(92, 81, 41, 6, 8500),
(93, 82, 18, 1, 1710),
(94, 82, 17, 1, 2610),
(95, 83, 30, 6, 19750),
(96, 84, 17, 2, 2610),
(97, 84, 18, 1, 1710),
(98, 84, 19, 1, 6375),
(99, 85, 23, 1, 3440),
(100, 85, 12, 1, 261.25),
(101, 86, 30, 1, 19750),
(102, 86, 17, 1, 2610),
(103, 86, 25, 1, 3000),
(104, 87, 12, 1, 261.25),
(105, 87, 9, 2, 2437.5),
(106, 88, 37, 1, 6840),
(107, 88, 25, 1, 3000),
(108, 89, 18, 2, 1710),
(109, 90, 36, 1, 7395),
(110, 91, 9, 1, 2437.5),
(111, 92, 22, 1, 2520),
(112, 93, 23, 2, 3440),
(113, 93, 12, 2, 261.25),
(114, 94, 30, 2, 19750),
(115, 94, 19, 1, 6375),
(116, 94, 24, 1, 2700),
(117, 95, 23, 1, 3440),
(118, 95, 29, 1, 36000),
(119, 96, 25, 1, 3000),
(120, 97, 35, 1, 5225),
(121, 98, 13, 2, 1485),
(122, 99, 19, 2, 6375),
(123, 100, 23, 3, 3440),
(124, 101, 11, 2, 720),
(125, 101, 12, 1, 261.25),
(126, 102, 11, 1, 720),
(127, 103, 11, 3, 720),
(128, 104, 12, 2, 261.25),
(129, 105, 12, 1, 261.25),
(130, 105, 18, 8, 1710),
(131, 106, 23, 2, 3440),
(132, 106, 30, 3, 19750),
(133, 106, 11, 11, 720),
(134, 107, 12, 5, 261.25),
(135, 108, 12, 2, 261.25),
(136, 109, 12, 2, 261.25),
(137, 110, 12, 1, 261.25),
(138, 111, 29, 1, 36000),
(139, 111, 40, 1, 5400),
(142, 114, 23, 3, 3440),
(143, 115, 12, 1, 261.25),
(144, 115, 23, 2, 3440);

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE IF NOT EXISTS `rating` (
  `rate_id` int(10) NOT NULL AUTO_INCREMENT,
  `rate` int(1) NOT NULL,
  `book_id` int(30) NOT NULL,
  `customer_id` int(20) NOT NULL,
  PRIMARY KEY (`rate_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=71 ;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`rate_id`, `rate`, `book_id`, `customer_id`) VALUES
(1, 4, 12, 28),
(2, 5, 23, 28),
(3, 4, 44, 28),
(4, 5, 11, 13),
(5, 5, 23, 13),
(6, 5, 30, 13),
(7, 2, 41, 13),
(8, 4, 31, 13),
(9, 5, 26, 1),
(10, 4, 18, 1),
(11, 5, 17, 1),
(12, 4, 19, 1),
(13, 4, 28, 1),
(14, 4, 16, 1),
(15, 5, 37, 1),
(16, 5, 25, 1),
(17, 5, 24, 1),
(18, 4, 39, 1),
(19, 3, 35, 1),
(20, 4, 11, 1),
(21, 4, 38, 1),
(22, 3, 14, 1),
(23, 4, 30, 8),
(24, 5, 13, 39),
(25, 4, 25, 39),
(26, 4, 23, 8),
(27, 4, 32, 8),
(28, 4, 22, 8),
(29, 4, 21, 1),
(30, 5, 20, 1),
(31, 5, 10, 1),
(32, 4, 12, 1),
(33, 5, 44, 8),
(34, 4, 34, 13),
(35, 4, 16, 13),
(36, 4, 9, 13),
(37, 5, 11, 10),
(38, 4, 23, 39),
(39, 5, 12, 39),
(40, 4, 12, 8),
(41, 4, 9, 8),
(42, 4, 41, 8),
(43, 4, 12, 13),
(44, 4, 40, 13),
(45, 4, 36, 13),
(46, 4, 8, 13),
(47, 4, 7, 13),
(48, 4, 30, 10),
(49, 4, 12, 10),
(50, 4, 17, 42),
(51, 4, 13, 42),
(52, 4, 16, 42),
(53, 4, 37, 42),
(54, 4, 12, 42),
(55, 4, 23, 10),
(56, 4, 23, 1),
(57, 5, 17, 10),
(58, 4, 25, 10),
(59, 4, 36, 8),
(60, 4, 16, 8),
(61, 5, 37, 44),
(62, 4, 25, 44),
(63, 4, 17, 44),
(64, 4, 18, 44),
(65, 4, 19, 13),
(66, 3, 15, 8),
(67, 3, 34, 8),
(68, 3, 22, 10),
(69, 3, 29, 13),
(70, 4, 7, 10);

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE IF NOT EXISTS `system_settings` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `email` varchar(200) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `cover_img` text NOT NULL,
  `about_content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `name`, `email`, `contact`, `cover_img`, `about_content`) VALUES
(1, 'Interactive Online Book Shop', 'info@mybooks.edu.lk', '+94714-4067-67', '', 'this is the Largest Book Store in Sri Lanka');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` text NOT NULL,
  `type` tinyint(1) NOT NULL COMMENT '1=Admin,2=Staff',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `type`) VALUES
(1, 'admin', 'admin', '0192023a7bbd73250516f069df18b500', 1),
(2, 'Pamitha Savunjith', 'pamitha', '2b88f18e7b1381f5c10e4f8538cfce3e', 2),
(4, 'mahesh2', 'mahesh ', '7cb323203b1306810d65271d8e9228ef', 2),
(5, 'Owner', 'superuser', '9a85a0cc0a56febcf46690a6ab1a5803', 1);

-- --------------------------------------------------------

--
-- Table structure for table `view_history`
--

CREATE TABLE IF NOT EXISTS `view_history` (
  `history_id` int(20) NOT NULL AUTO_INCREMENT,
  `book_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  PRIMARY KEY (`history_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=539 ;

--
-- Dumping data for table `view_history`
--

INSERT INTO `view_history` (`history_id`, `book_id`, `user_id`) VALUES
(1, 33, 8),
(8, 11, 14),
(9, 8, 14),
(10, 32, 14),
(16, 37, 28),
(44, 26, 28),
(45, 19, 28),
(47, 11, 28),
(82, 30, 29),
(85, 12, 29),
(87, 23, 29),
(95, 41, 29),
(105, 12, 28),
(116, 38, 13),
(123, 26, 1),
(124, 18, 1),
(125, 17, 1),
(126, 19, 1),
(127, 28, 1),
(128, 16, 1),
(129, 37, 1),
(130, 25, 1),
(131, 24, 1),
(132, 39, 1),
(133, 35, 1),
(135, 38, 1),
(136, 14, 1),
(142, 32, 8),
(147, 21, 1),
(148, 20, 1),
(151, 10, 1),
(159, 22, 8),
(162, 20, 8),
(163, 44, 8),
(165, 44, 13),
(174, 41, 10),
(192, 30, 8),
(205, 31, 8),
(215, 40, 13),
(216, 36, 13),
(218, 9, 13),
(219, 8, 13),
(228, 26, 13),
(229, 41, 13),
(255, 13, 42),
(260, 28, 42),
(262, 16, 42),
(263, 37, 42),
(269, 12, 42),
(276, 30, 42),
(277, 23, 42),
(278, 31, 42),
(279, 41, 42),
(280, 39, 42),
(282, 25, 42),
(283, 24, 42),
(284, 32, 42),
(285, 35, 42),
(286, 22, 42),
(287, 36, 42),
(288, 11, 42),
(294, 7, 13),
(297, 32, 13),
(298, 16, 13),
(308, 30, 1),
(316, 16, 8),
(319, 30, 44),
(320, 17, 44),
(326, 15, 8),
(327, 34, 8),
(336, 17, 39),
(337, 23, 1),
(344, 21, 39),
(349, 23, 39),
(355, 11, 5),
(359, 11, 13),
(360, 28, 13),
(361, 37, 13),
(418, 12, 8),
(451, 23, 8),
(488, 31, 13),
(509, 12, 10),
(510, 7, 10),
(524, 12, 39),
(526, 30, 39),
(536, 30, 13);

-- --------------------------------------------------------

--
-- Table structure for table `wish_list`
--

CREATE TABLE IF NOT EXISTS `wish_list` (
  `wish_id` int(20) NOT NULL AUTO_INCREMENT,
  `book_id` int(10) NOT NULL,
  `customer_id` int(10) NOT NULL,
  PRIMARY KEY (`wish_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `wish_list`
--

INSERT INTO `wish_list` (`wish_id`, `book_id`, `customer_id`) VALUES
(7, 12, 28),
(8, 30, 28),
(10, 25, 39),
(11, 40, 13),
(12, 31, 10),
(13, 30, 10),
(14, 20, 13),
(15, 34, 39),
(16, 12, 39),
(17, 23, 13);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
