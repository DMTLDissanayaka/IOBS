<?php 
include 'admin/db_connect.php'; 
?>
<style>
    #cat-list li{
        cursor: pointer;
    }
       #cat-list li:hover {
        color: white;
        background: #007bff8f;
    }
    .prod-item p{
        margin: unset;
    }
    .bid-tag {
    position: absolute;
    right: .5em;
}
</style>
<?php 
$cid = isset($_GET['category_id']) ? $_GET['category_id'] : 0;
?>
<div class="contain-fluid">
    <div class="col-lg-12">
        <div class="row">
            <div class="col-md-3">
                <div class="card">
					<div class="card-header"><b>Advanced Search</b></div>
                    <div class="card-body">
                        <div class="col-lg-14">
                            <form method="post">
                                <div class="form-group" align="center">
                                    <label for="" class="control-label">Search by Book Name, Author Name, ISBN or keyword</label>
                                    <input type="text" name="search" id="search" value="<?php if(isset($_REQUEST['search'])){ echo $_REQUEST['search']; }?>" class="form-control" />
                                    </br>
                                    <input type="number" step="any" min="0" placeholder="Price From" name="price_from" id="price_from" value="<?php if(isset($_REQUEST['price_from'])){ echo $_REQUEST['price_from']; }?>" class="form-control" />
									</br>
                                    <input type="number" step="any" min="0" placeholder="Price Up To" name="price_to" id="price_to" value="<?php if(isset($_REQUEST['price_to'])){ echo $_REQUEST['price_to']; }?>" class="form-control" />
                                    </br>
                                    <input type="hidden" name="page" value="<?php if(isset($_REQUEST['page'])){ echo $_REQUEST['page'];}?>" />
                                    <input type="submit" name="Book Search" value="Search" class="btn btn-primary btn-sm" />
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="card-header"><b>Search by Categories</b></div>
                    <div class="card-body">
                        <ul class='list-group' id='cat-list'>
                            <li class='list-group-item' data-id='all' data-href="index.php?page=home&category_id=all">All</li>
                            <?php
                                $cat = $conn->query("SELECT * FROM categories order by name asc");
                                while($row=$cat->fetch_assoc()):
                                    $cat_arr[$row['id']] = $row['name'];
                             ?>
                            <li class='list-group-item' data-id='<?php echo $row['id'] ?>' data-href="index.php?page=home&category_id=<?php echo $row['id'] ?>"><?php echo ucwords($row['name']) ?></li>

                            <?php endwhile; ?>
                        </ul>

                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="card">
                    <div class="card-body">
                       
				<div class="container-fluid">

				<div class="col-lg-12">
					<div class="row">
						<!-- Table Panel -->
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<b><h4>Your Order List </h4></b>
								</div>
								<div class="card-body">
									<table class="table table-bordered table-hover">
										<colgroup>
											
											<col width="5%">
											<col width="20%">
											<col width="15%">
											<col width="15%">
											
											
										</colgroup>
										<thead>
											<tr>
												<th class="text-center">#</th>
												<th class="text-center">Order number</th>
												<th class="text-center">Order Date</th>
												<th class="text-center">Tracking number</th>
												
												
											</tr>
										</thead>
										<tbody>
											<?php 
											$i = 1;
											$qry = $conn->query("SELECT * FROM orders where customer_id ={$_SESSION['login_id']} order by date_created desc ");
											while($row=$qry->fetch_array()):
											
											?>
											<tr>
												<td class="text-center"><?php echo $i++ ?></td>
												<td class="">
													<p><b><?php echo ucwords($row['id']) ?></b></p>
												</td>
												<td class="">
													<p><b><?php echo date("M d,Y",strtotime($row['date_created'])) ?></b></p>
												</td>
												<td class="">
													<p><b><a class="nav-link js-scroll-trigger" href="https://www.domex.lk/tracking.php?wbno=<?php echo ($row['delivery_ref_no']) ?>"><?php echo ($row['delivery_ref_no']) ?></a></b></p>
												</td>
																						
												</td>
											</tr>
											<?php endwhile; ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
						<!-- Table Panel -->
					</div>
				</div>	

				</div>


					   
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

       
<script>
    $('#cat-list li').click(function(){
        location.href = $(this).attr('data-href')
    })
     $('#cat-list li').each(function(){
        var id = '<?php echo $cid > 0 ? $cid : 'all' ?>';
        if(id == $(this).attr('data-id')){
            $(this).addClass('active')
        }
    })
     $('.view_prod').click(function(){
        uni_modal_right('View Book','view_prod.php?id='+$(this).attr('data-id'))
     })
</script>