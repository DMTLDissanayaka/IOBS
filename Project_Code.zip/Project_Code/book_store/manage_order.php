<?php 
session_start() ;

$shipping_address = "";
if(isset($_SESSION['login_email']) && strlen($_SESSION['login_email']) > 0){
	$shipping_address = $_SESSION['login_str_no'].", ".$_SESSION['login_str_name'].", ".$_SESSION['login_city'].", ".$_SESSION['login_country'].", ".$_SESSION['login_postal_code'];	
}
?>
<div class="container-fluid">
	<div class="col-lg-12">
    <form id="manage-order">
    
        <h5><input type="radio" name="pay_type" id="pay_type1" checked  onChange="disFilds(2)" value="0" >&nbsp;&nbsp;&nbsp;Cash On Delivery</h5>
        <p>Please wait for verification email or call from the management after checking out</p>
		
        <div class="form-group">
            <label for="" class="control-label">Delivery Address</label>
            <textarea name="address" id="address1" cols="30" rows="4" class="form-control" required><?php echo $shipping_address; ?></textarea>
        </div>

        <h5><input type="radio" name="pay_type" id="pay_type2" onChange="disFilds(1)" value="1">&nbsp;&nbsp;&nbsp;Pay Online</h5>
        <p> Make payment with Debit&nbsp;/&nbsp;Credit card</p>
		<div class="form-group">
            <label for="" class="control-label">Delivery Address</label>
            <textarea name="address" id="address1" cols="30" rows="4" class="form-control" required><?php echo $shipping_address; ?></textarea>
        </div>	
			
		</div>
	</form>        
</div>
<script>
	disFilds(2);
	function disFilds(field){
		if(field==1){
			$("#address1").prop("disabled", true);
			
							

		}else if(field==2){
			$("#address1").prop("disabled", false);
			
							
		}
	}

</script>

<script>
	$('#manage-order').submit(function(e){
		e.preventDefault()
		start_load()
		$.ajax({
			url:'admin/ajax.php?action=save_order',
			method:'POST',
			data:$(this).serialize(),
			//error:err=>{
			//	console.log(err)
			//},
			success:function(resp){
				if(resp == 1){
					alert_toast('Order successfully submitted.',"success");
					setTimeout(function(){
						location.reload()
					},750)
				}
			}
		})
	})
</script>