<?php include 'admin/db_connect.php' ?>
<?php
session_start();
if(isset($_GET['id'])){
$qry = $conn->query("SELECT * FROM books where id= ".$_GET['id']);
foreach($qry->fetch_array() as $k => $val){
	$$k=$val;
}
if(!empty($category_ids))
	$cat_qry = $conn->query("SELECT * FROM categories where id in ($category_ids)");
	$cname = array();
	while($row=$cat_qry->fetch_array()){
    	$cname[$row['id']] = ucwords($row['name']);
	}
}
if(isset($_SESSION['login_id'])){
	$select_history="SELECT history_id from `view_history` WHERE book_id = '$id' and user_id = ".$_SESSION['login_id'];
    $select_history_result=mysqli_query($conn,$select_history);
    if(mysqli_num_rows($select_history_result) > 0){
		$delete_history = "DELETE from `view_history` WHERE book_id = '$id' and user_id = ".$_SESSION['login_id']; 
		mysqli_query($conn,$delete_history);
	}
	$sql = "INSERT INTO `view_history` (`history_id`,`book_id`,`user_id`) 
	VALUES (NULL, '$id','".$_SESSION['login_id']."')";
	mysqli_query($conn,$sql);

}

?>
<style type="text/css">
	
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }
    #qty{
        width: 50px;
        text-align: center
    }
</style>

<div class="container-fluid">
	<img src="admin/assets/uploads/<?php echo $image_path ?>" class="d-flex w-100" alt="">
	<p>Title: <large><b><?php echo $title ?></b></large></p>
	<p>ISBN: <large><b><?php echo $isbn ?></b></large></p>
    <p>Author: <b><?php echo $author ?></b></p>
	<p>Category: <b>
    <?php 
      $cats = '';
      $cat = explode(',', $category_ids);
      foreach ($cat as $key => $value) {
        if(!empty($cats)){
          $cats .=", ";
        }
        if(isset($cname[$value])){
          $cats .= $cname[$value];
        }
      }
      echo $cats;
      ?>
    </b></p>
    <p>Price: <b><?php echo number_format($price,2) ?></b></p>
    <?php
	if($discount_per > 0){
	?>
    <p>Discount: <b><?php echo $discount_per."%"; ?></b></p>
    <p>Discounted Price: <b><?php echo number_format($price-($price*$discount_per/100),2); ?></b></p>
    <?php
	}
	?>
	<p>Description:</p>
	<p class=""><small><i><?php echo $description ?></i></small></p>
    <p>Your Rating:</p>
	<?php    
    $own_book_rate = 0;
	$rate = $conn->query("SELECT rate from rating where book_id = '".$id."' and customer_id='".$_SESSION['login_id']."'");
    $rate_row=$rate->fetch_assoc();
	$own_book_rate = $rate_row['rate'];	

	if($own_book_rate==0 || trim($own_book_rate) == ""){
    ?>
    <p id="rate_area">
    	<img src="assets/img/gray.png" height="32" id="img1_g" onMouseOver="getColoured('1_g')">
        <img src="assets/img/yellow.png" height="32" id="img1_y" onMouseOut="getColoured('1_y')" onClick="markColour(1,<?php echo $id;?>)">
        <img src="assets/img/gray.png" height="32" id="img2_g" onMouseOver="getColoured('2_g')">
        <img src="assets/img/yellow.png" height="32" id="img2_y" onMouseOut="getColoured('2_y')" onClick="markColour(2,<?php echo $id;?>)">
        <img src="assets/img/gray.png" height="32" id="img3_g" onMouseOver="getColoured('3_g')">
        <img src="assets/img/yellow.png" height="32" id="img3_y" onMouseOut="getColoured('3_y')" onClick="markColour(3,<?php echo $id;?>)">
        <img src="assets/img/gray.png" height="32" id="img4_g" onMouseOver="getColoured('4_g')">
        <img src="assets/img/yellow.png" height="32" id="img4_y" onMouseOut="getColoured('4_y')" onClick="markColour(4,<?php echo $id;?>)">
        <img src="assets/img/gray.png" height="32" id="img5_g" onMouseOver="getColoured('5_g')">
        <img src="assets/img/yellow.png" height="32" id="img5_y" onMouseOut="getColoured('5_y')" onClick="markColour(5,<?php echo $id;?>)">
    </p>
	<?php
	}elseif($own_book_rate == 1){
	?>
    <p id="rate_area">
        <img src="assets/img/yellow.png" height="32" onClick="markColour(1,<?php echo $id;?>)">
        <img src="assets/img/gray.png" height="32" id="img2_g" onMouseOver="getColoured('2_g')">
        <img src="assets/img/yellow.png" height="32" id="img2_y" onMouseOut="getColoured('2_y')" onClick="markColour(2,<?php echo $id;?>)">
        <img src="assets/img/gray.png" height="32" id="img3_g" onMouseOver="getColoured('3_g')">
        <img src="assets/img/yellow.png" height="32" id="img3_y" onMouseOut="getColoured('3_y')" onClick="markColour(3,<?php echo $id;?>)">
        <img src="assets/img/gray.png" height="32" id="img4_g" onMouseOver="getColoured('4_g')">
        <img src="assets/img/yellow.png" height="32" id="img4_y" onMouseOut="getColoured('4_y')" onClick="markColour(4,<?php echo $id;?>)">
        <img src="assets/img/gray.png" height="32" id="img5_g" onMouseOver="getColoured('5_g')">
        <img src="assets/img/yellow.png" height="32" id="img5_y" onMouseOut="getColoured('5_y')" onClick="markColour(5,<?php echo $id;?>)">
    </p>
    <?php
	}elseif($own_book_rate == 2){
	?>
    <p id="rate_area">
        <img src="assets/img/yellow.png" height="32" onClick="markColour(1,<?php echo $id;?>)">
        <img src="assets/img/yellow.png" height="32" onClick="markColour(2,<?php echo $id;?>)">
        <img src="assets/img/gray.png" height="32" id="img3_g" onMouseOver="getColoured('3_g')">
        <img src="assets/img/yellow.png" height="32" id="img3_y" onMouseOut="getColoured('3_y')" onClick="markColour(3,<?php echo $id;?>)">
        <img src="assets/img/gray.png" height="32" id="img4_g" onMouseOver="getColoured('4_g')">
        <img src="assets/img/yellow.png" height="32" id="img4_y" onMouseOut="getColoured('4_y')" onClick="markColour(4,<?php echo $id;?>)">
        <img src="assets/img/gray.png" height="32" id="img5_g" onMouseOver="getColoured('5_g')">
        <img src="assets/img/yellow.png" height="32" id="img5_y" onMouseOut="getColoured('5_y')" onClick="markColour(5,<?php echo $id;?>)">
    </p>
    <?php
	}elseif($own_book_rate == 3){
	?>
    <p id="rate_area">
        <img src="assets/img/yellow.png" height="32" onClick="markColour(1,<?php echo $id;?>)">
        <img src="assets/img/yellow.png" height="32" onClick="markColour(2,<?php echo $id;?>)">
        <img src="assets/img/yellow.png" height="32" onClick="markColour(3,<?php echo $id;?>)">
        <img src="assets/img/gray.png" height="32" id="img4_g" onMouseOver="getColoured('4_g')">
        <img src="assets/img/yellow.png" height="32" id="img4_y" onMouseOut="getColoured('4_y')" onClick="markColour(4,<?php echo $id;?>)">
        <img src="assets/img/gray.png" height="32" id="img5_g" onMouseOver="getColoured('5_g')">
        <img src="assets/img/yellow.png" height="32" id="img5_y" onMouseOut="getColoured('5_y')" onClick="markColour(5,<?php echo $id;?>)">
    </p>
    <?php
	}elseif($own_book_rate == 4){
	?>
    <p id="rate_area">
        <img src="assets/img/yellow.png" height="32" onClick="markColour(1,<?php echo $id;?>)">
        <img src="assets/img/yellow.png" height="32" onClick="markColour(2,<?php echo $id;?>)">
        <img src="assets/img/yellow.png" height="32" onClick="markColour(3,<?php echo $id;?>)">
        <img src="assets/img/yellow.png" height="32" onClick="markColour(4,<?php echo $id;?>)">
        <img src="assets/img/gray.png" height="32" id="img5_g" onMouseOver="getColoured('5_g')">
        <img src="assets/img/yellow.png" height="32" id="img5_y" onMouseOut="getColoured('5_y')" onClick="markColour(5,<?php echo $id;?>)">
    </p>
    <?php
	}elseif($own_book_rate == 5){
	?>
    <p id="rate_area">
        <img src="assets/img/yellow.png" height="32" onClick="markColour(1,<?php echo $id;?>)">
        <img src="assets/img/yellow.png" height="32" onClick="markColour(2,<?php echo $id;?>)">
        <img src="assets/img/yellow.png" height="32" onClick="markColour(3,<?php echo $id;?>)">
        <img src="assets/img/yellow.png" height="32" onClick="markColour(4,<?php echo $id;?>)">
        <img src="assets/img/yellow.png" height="32" onClick="markColour(5,<?php echo $id;?>)">
    </p>
    <?php
	}
	?>
	
	<?php if($stock_balance>0){
	?>
		<p><b><?php echo "Available quantity is:"?> <?php echo $stock_balance  ?></b></p
	<?php } ?>		
	

    <div class="d-flex jusctify-content-center col-md-12">
        <?php
		if($stock_balance > 0){
		?>
		
        <div class="d-flex col-sm-5">
            <span class="btn btn-sm btn-secondary btn-minus"><b><i class="fa fa-minus"></i></b></span>
            <input type="number" name="qty" id="qty" value="1">
            <span class="btn btn-sm btn-secondary btn-plus"><b><i class="fa fa-plus"></i></b></span>
        </div>
		<button class="btn btn-primary btn-block btn-sm col-sm-6" type="button" id="add_to_cart">Add to Cart</button>
        
		<?php
		}else{
		?>
        <button class="btn btn-secondary btn-block btn-sm col-sm-4" type="button" >Out of Stock</button>
        <?php
		}
		?>
	</div>
</div>
<script>
    $('.btn-minus').click(function(){
            var qty = $(this).siblings('input').val()
                qty = qty > 1 ? parseInt(qty) - 1 : 1;
                $(this).siblings('input').val(qty).trigger('change')
         })
     $('.btn-plus').click(function(){
        var qty = $(this).siblings('input').val()
            qty = parseInt(qty) + 1;
            $(this).siblings('input').val(qty).trigger('change')
     })
// $('#manage_bid')
$('#add_to_cart').click(function(){
    if('<?php echo !isset($_SESSION['login_id']) ?>' == 1){
            uni_modal("Please Login First",'login.php')
            return false
    }
    start_load()

    $.ajax({
        url:'admin/ajax.php?action=add_to_cart',
        method:'POST',
        data:{book_id: '<?php echo $id ?>',price: '<?php echo $price ?>',discount_per: '<?php echo $discount_per ?>', qty:$('#qty').val()},
        success:function(resp){
            if(resp == 1){
                alert_toast("Book successfully added to cart.","success")
                end_load()
                load_cart()
            }
        }
    })
})	

function markColour(img_id,book_id){
	//alert(img_id);	
	//alert(book_id);	
    
	start_load()

    $.ajax({
        url:'admin/ajax.php?action=add_rate',
        method:'POST',
        data:{book_id: book_id,rate: img_id},
        success:function(resp){
            if(resp == 1 || resp == 2 || resp == 3 || resp == 4 || resp == 5 ){
                alert_toast("Rated for the book successfully.","success")
                if(resp == 1){
					document.getElementById("rate_area").innerHTML = "<img src='assets/img/yellow.png' height='32' id='img1_y' onClick='markColour(1,<?php echo $id;?>)'><img src='assets/img/gray.png' height='32' id='img5_g' onClick='markColour(2,<?php echo $id;?>)'><img src='assets/img/gray.png' height='32' id='img5_g' onClick='markColour(3,<?php echo $id;?>)'><img src='assets/img/gray.png' height='32' id='img5_g' onClick='markColour(4,<?php echo $id;?>)'><img src='assets/img/gray.png' height='32' id='img5_g' onClick='markColour(5,<?php echo $id;?>)'>";
				}else if(resp == 2){
					document.getElementById("rate_area").innerHTML = "<img src='assets/img/yellow.png' height='32' id='img1_y' onClick='markColour(1,<?php echo $id;?>)'><img src='assets/img/yellow.png' height='32' id='img1_y' onClick='markColour(2,<?php echo $id;?>)'><img src='assets/img/gray.png' height='32' id='img5_g' onClick='markColour(3,<?php echo $id;?>)'><img src='assets/img/gray.png' height='32' id='img5_g' onClick='markColour(4,<?php echo $id;?>)'><img src='assets/img/gray.png' height='32' id='img5_g' onClick='markColour(5,<?php echo $id;?>)'>";
				}else if(resp == 3){
					document.getElementById("rate_area").innerHTML = "<img src='assets/img/yellow.png' height='32' id='img1_y' onClick='markColour(1,<?php echo $id;?>)'><img src='assets/img/yellow.png' height='32' id='img1_y' onClick='markColour(2,<?php echo $id;?>)'><img src='assets/img/yellow.png' height='32' id='img1_y' onClick='markColour(3,<?php echo $id;?>)'><img src='assets/img/gray.png' height='32' id='img5_g' onClick='markColour(4,<?php echo $id;?>)'><img src='assets/img/gray.png' height='32' id='img5_g' onClick='markColour(5,<?php echo $id;?>)'>";
				}else if(resp == 4){
					document.getElementById("rate_area").innerHTML = "<img src='assets/img/yellow.png' height='32' id='img1_y' onClick='markColour(1,<?php echo $id;?>)'><img src='assets/img/yellow.png' height='32' id='img1_y' onClick='markColour(2,<?php echo $id;?>)'><img src='assets/img/yellow.png' height='32' id='img1_y' onClick='markColour(3,<?php echo $id;?>)'><img src='assets/img/yellow.png' height='32' id='img1_y' onClick='markColour(4,<?php echo $id;?>)'><img src='assets/img/gray.png' height='32' id='img5_g' onClick='markColour(5,<?php echo $id;?>)'>";
					//$("#img5_y").hide();
				}else if(resp == 5){
					document.getElementById("rate_area").innerHTML = "<img src='assets/img/yellow.png' height='32' id='img1_y' onClick='markColour(1,<?php echo $id;?>)'><img src='assets/img/yellow.png' height='32' id='img1_y' onClick='markColour(2,<?php echo $id;?>)'><img src='assets/img/yellow.png' height='32' id='img1_y' onClick='markColour(3,<?php echo $id;?>)'><img src='assets/img/yellow.png' height='32' id='img1_y' onClick='markColour(4,<?php echo $id;?>)'><img src='assets/img/yellow.png' height='32' id='img1_y' onClick='markColour(5,<?php echo $id;?>)'>";
				}
				end_load()
            }
        }
    })	
}

function getColoured(img_id){
	//alert(img_id);
	//set to yellow
	if(img_id == '1_g'){
		$("#img1_g").hide();	
		$("#img1_y").show();	
	}
	if(img_id == '2_g'){
		$("#img1_g").hide();	
		$("#img1_y").show();	

		$("#img2_g").hide();	
		$("#img2_y").show();	
	}
	if(img_id == '3_g'){
		$("#img1_g").hide();	
		$("#img1_y").show();	

		$("#img2_g").hide();	
		$("#img2_y").show();	

		$("#img3_g").hide();	
		$("#img3_y").show();	
	}
	if(img_id == '4_g'){
		$("#img1_g").hide();	
		$("#img1_y").show();	

		$("#img2_g").hide();	
		$("#img2_y").show();	

		$("#img3_g").hide();	
		$("#img3_y").show();	

		$("#img4_g").hide();	
		$("#img4_y").show();	
	}
	if(img_id == '5_g'){
		$("#img1_g").hide();	
		$("#img1_y").show();	

		$("#img2_g").hide();	
		$("#img2_y").show();	

		$("#img3_g").hide();	
		$("#img3_y").show();	

		$("#img4_g").hide();	
		$("#img4_y").show();	

		$("#img5_g").hide();	
		$("#img5_y").show();	
	}
	//set to gray
	if(img_id == '1_y'){
		$("#img1_g").show();	
		$("#img1_y").hide();	
	}
	if(img_id == '2_y'){
		$("#img1_g").show();	
		$("#img1_y").hide();	

		$("#img2_g").show();	
		$("#img2_y").hide();	
	}
	if(img_id == '3_y'){
		$("#img1_g").show();	
		$("#img1_y").hide();	

		$("#img2_g").show();	
		$("#img2_y").hide();	

		$("#img3_g").show();	
		$("#img3_y").hide();	
	}
	if(img_id == '4_y'){
		$("#img1_g").show();	
		$("#img1_y").hide();	

		$("#img2_g").show();	
		$("#img2_y").hide();	

		$("#img3_g").show();	
		$("#img3_y").hide();	

		$("#img4_g").show();	
		$("#img4_y").hide();	
	}
	if(img_id == '5_y'){
		$("#img1_g").show();	
		$("#img1_y").hide();	

		$("#img2_g").show();	
		$("#img2_y").hide();	

		$("#img3_g").show();	
		$("#img3_y").hide();	

		$("#img4_g").show();	
		$("#img4_y").hide();	

		$("#img5_g").show();	
		$("#img5_y").hide();	
	}	
}

$("#img1_y").hide();
$("#img2_y").hide();
$("#img3_y").hide();
$("#img4_y").hide();
$("#img5_y").hide();

</script>