<?php session_start() ?>
<?php include('admin/db_connect.php'); ?>
<?php 
if(isset($_SESSION['login_id'])){
	$qry = $conn->query("SELECT * from customers where id = {$_SESSION['login_id']} ");
	foreach($qry->fetch_array() as $k => $v){
		$$k = $v;
	}
}
?>
<div class="container-fluid">
	<form action="" id="signup-frm">
		<input type="hidden" name="id" value="<?php echo isset($id) ? $id : '' ?>">
		<div class="row">
			<div class="col-md-6 border-right">
				<div class="form-group">
					<label for="" class="control-label">First Name</label>
					<input type="text" name="name" required class="form-control" value="<?php echo isset($name) ? $name : '' ?>">
				</div>
				<div class="form-group">
					<label for="" class="control-label">last Name</label>
					<input type="text" name="lname" required class="form-control" value="<?php echo isset($lname) ? $lname : '' ?>">
				</div>
				<div class="form-group">
					<label for="" class="control-label">Street Number</label>
					<input type="text" name="str_no" required class="form-control" value="<?php echo isset($str_no) ? $str_no : '' ?>">
				</div>
				<div class="form-group">
					<label for="" class="control-label">Street Name</label>
					<input type="text" name="str_name" required class="form-control" value="<?php echo isset($str_name) ? $str_name : '' ?>">
				</div>
				<div class="form-group">
					<label for="" class="control-label">City</label>
					<input type="text" name="city" required class="form-control" value="<?php echo isset($city) ? $city : '' ?>">
				</div>
				<div class="form-group">
					<label for="" class="control-label">Postal Code</label>
					<input type="text" name="postal_code" required class="form-control" value="<?php echo isset($postal_code) ? $postal_code : '' ?>">
				</div>
				<div class="form-group">
					<label for="" class="control-label">Country</label>
					<input type="text" name="country" required class="form-control" value="<?php echo isset($country) ? $country : '' ?>">
				</div>
                
			</div>
			<div class="col-md-6">		
				
				<div class="form-group">
					<label for="" class="control-label">Age</label>
					<input type="text" name="age" required class="form-control" value="<?php echo isset($age) ? $age : '' ?>">
				</div>
				
				<div class="form-group">
						<label class="label control-label">Category</label>
						<select name="category_ids[]" id="" class="custom-select custom-select-sm select2" required multiple="multiple">
							<option value=""></option>
							<?php
							$categories = $conn->query("SELECT * FROM categories order by name asc");
							while($row= $categories->fetch_assoc()):
							?>
							<option value="<?php echo $row['id'] ?>" <?php echo isset($category_ids) && !empty($category_ids) &&  in_array($row['id'],explode(',',$category_ids)) ? 'selected' : '' ?>><?php echo ucwords($row['name']) ?></option>
						<?php endwhile; ?>
						</select>
				</div>
				
				<div class="form-group">
					<label for="" class="control-label">Contact</label>
					<input type="number" name="contact" required class="form-control" value="<?php echo isset($contact) ? $contact : '' ?>">
				</div>
				<div class="form-group">
					<label for="" class="control-label">Email</label>
					<input type="email" name="email" required class="form-control" value="<?php echo isset($email) ? $email : '' ?>">
				</div>
				<div class="form-group">
					<label for="" class="control-label">Password</label>
					<input type="password" name="password" class="form-control" <?php echo isset($email) ? '' : "required"?>>
					<?php if(isset($id)): ?>
						<small><i>Leave this field blank if you dont want to change your password.</i></small>
					<?php endif; ?>
				</div>
                <div class="form-group">
					<label for="" class="control-label">Confirm Password</label>
					<input type="password" name="conf_password" class="form-control" >
				</div>
				<div class="form-group">
					<button class="button btn btn-primary btn-sm"><?php echo !isset($id) ? "Create" : "Update" ?></button>
					<button class="button btn btn-secondary btn-sm" type="button" data-dismiss="modal">Cancel</button>
				<div>
			</div>


	</form>
</div>

<style>
	#uni_modal .modal-footer{
		display:none;
	}
</style>
<script>
	$('.select2').select2({
		placeholder:"Please Select Here",
		width:'100%'
	})
	$('.number').on('input',function(){
        var val = $(this).val()
        val = val.replace(/,/g,'') 
        val = val > 0 ? val : 0;
        $(this).val(parseFloat(val).toLocaleString("en-US"))
    })


	$('#signup-frm').submit(function(e){
		e.preventDefault()
		start_load()
		if($(this).find('.alert-danger').length > 0 )
			$(this).find('.alert-danger').remove();
		$.ajax({
			url:'admin/ajax.php?action=signup',
			method:'POST',
			data:$(this).serialize(),
			error:err=>{
				console.log(err)
		$('#signup-frm button[type="submit"]').removeAttr('disabled').html('Create');

			},
			success:function(resp){
				if(resp == 1){
					location.reload();
				}else if(resp == 5){
					$('#signup-frm').prepend('<div class="alert alert-danger">Password & Confirm Password Mismatch.</div>')
					end_load()
				}else if(resp == 6){
					$('#signup-frm').prepend('<div class="alert alert-danger">Invalid Contact No.</div>')
					end_load()
				}else{
					$('#signup-frm').prepend('<div class="alert alert-danger">Email already exist.</div>')
					end_load()
				}
			}
		})
	})
	
	$('#signup').submit(function(e){
		e.preventDefault()
		$('input').removeClass("border-danger")
		start_load()
		$('#msg').html('')
		$.ajax({
			url:'ajax.php?action=signup',
			data: new FormData($(this)[0]),
		    cache: false,
		    contentType: false,
		    processData: false,
		    method: 'POST',
		    type: 'POST',
			error:err=>{
				console.log(err)
			},
			success:function(resp){
				if(resp == 1){
					alert_toast('Data successfully saved.',"success");
					setTimeout(function(){
						location.reload()
					},750)
				}
			}
		})
	})
</script>