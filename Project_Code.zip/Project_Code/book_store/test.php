
<form action="" method="post">
	
Name:<input type="number" name="num"/>
	 <input type="submit" name="submit" value="submit">
</form>
<?php 
	if (isset($_POST['submit'])){
		echo $_POST['num'];
	}
?>
<button class="button btn btn-primary btn-sm"> <a class="nav-link js-scroll-trigger" href="https://www.domex.lk/tracking.php?wbno=(<?php echo $_POST['num'];)?>">Track</a></button>