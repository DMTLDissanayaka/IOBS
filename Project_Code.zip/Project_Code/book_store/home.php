<?php 
include 'admin/db_connect.php'; 
?>
<style>
    #cat-list li{
        cursor: pointer;
    }
       #cat-list li:hover {
        color: white;
        background: #007bff8f;
    }
    .prod-item p{
        margin: unset;
    }
    .bid-tag {
    position: absolute;
    right: .5em;
}
</style>
<?php 
$cid = isset($_GET['category_id']) ? $_GET['category_id'] : 0;
?>
<div class="contain-fluid">
    <div class="col-lg-12">
        <div class="row">
            <div class="col-md-3">
                <div class="card">
					<div class="card-header"><b>Advanced Search</b></div>
                    <div class="card-body">
                        <div class="col-lg-14">
                            <form method="post">
                                <div class="form-group" align="center">
                                    <label for="" class="control-label">Search by Book Name, Author Name, ISBN or keyword</label>
                                    <input type="text" name="search" id="search" value="<?php if(isset($_REQUEST['search'])){ echo $_REQUEST['search']; }?>" class="form-control" />
                                    <br>
									<label for="" class="control-label">Search by Price Range</label>
                                    <input type="number" step="any" min="0" placeholder="Price From" name="price_from" id="price_from" value="<?php if(isset($_REQUEST['price_from'])){ echo $_REQUEST['price_from']; }?>" class="form-control" />
									<input type="number" step="any" min="0" placeholder="Price Up To" name="price_to" id="price_to" value="<?php if(isset($_REQUEST['price_to'])){ echo $_REQUEST['price_to']; }?>" class="form-control" />
                                    <input type="hidden" name="page" value="<?php if(isset($_REQUEST['page'])){ echo $_REQUEST['page'];}?>" />
                                    <br>
									<input type="submit" name="Book Search" value="Search" class="btn btn-primary btn-sm" />
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="card-header"><b>Search by Categories</b></div>
                    <div class="card-body">
                        <ul class='list-group' id='cat-list'>
                            <li class='list-group-item' data-id='all' data-href="index.php?page=home&category_id=all">All</li>
                            <?php
                                $cat = $conn->query("SELECT * FROM categories order by name asc");
                                while($row=$cat->fetch_assoc()):
                                    $cat_arr[$row['id']] = $row['name'];
                             ?>
                            <li class='list-group-item' data-id='<?php echo $row['id'] ?>' data-href="index.php?page=home&category_id=<?php echo $row['id'] ?>"><?php echo ucwords($row['name']) ?></li>

                            <?php endwhile; ?>
                        </ul>

                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="card">
					
                    <div class="card-body">
                        <div class="row">
                            <?php
                                $condition = "";
                                if((isset($_REQUEST['search']) && trim($_REQUEST['search']) != "") || (isset($_REQUEST['price_from']) && $_REQUEST['price_from'] > 0) || (isset($_REQUEST['price_to']) && $_REQUEST['price_to'] > 0)){
									if(isset($_REQUEST['search']) && trim($_REQUEST['search']) != ""){
										$condition.= " and (title LIKE '%".$_REQUEST['search']."%' or isbn LIKE '%".$_REQUEST['search']."%' or author LIKE '%".$_REQUEST['search']."%' or description LIKE '%".$_REQUEST['search']."%')";
									}
									if(isset($_REQUEST['price_from']) && $_REQUEST['price_from'] > 0){
										$condition.= " and price >= '".$_REQUEST['price_from']."'";
									}
									if(isset($_REQUEST['price_to']) && $_REQUEST['price_to'] > 0){
										$condition.= " and price <= '".$_REQUEST['price_to']."'";
									}
								}elseif($cid > 0){
                                    $condition.= " and CONCAT('[',REPLACE(category_ids,',','],['),']') LIKE '%[".$cid."]%'  ";
                                }
                                if(isset($_REQUEST['history']) && $_REQUEST['history'] == 1){
									$books = $conn->query("SELECT * from books as b, view_history as h where b.id = h.book_id and h.user_id = '".$_SESSION['login_id']."' order by h.history_id desc");
								}elseif(isset($_REQUEST['wish']) && $_REQUEST['wish'] == 1){
									$books = $conn->query("SELECT * from books as b, wish_list as w where b.id = w.book_id and w.customer_id = '".$_SESSION['login_id']."' order by w.wish_id desc");
								}else{
									$books = $conn->query("SELECT * from books where id > 0 $condition order by title asc");
								}
                                if($books->num_rows <= 0){
                                    echo "<center><h4><i>No Available Product.</i></h4></center>";
                                } 
                                while($row=$books->fetch_assoc()):
                             ?>
                             <div class="col-sm-4">
                                 <div class="card">
									<div class="float-right align-top bid-tag">
                                         <span class="badge badge-pill badge-success text-white"><i class="fa fa-tag"></i><B> Rs:&nbsp;<?php echo number_format(($row['price']),2) ?></B></span>
									</div>
									<?php
									if($row['discount_per'] > 0){
									?>
                                    <div class="float-right align-top bid-tag">
                                         <br>
										 <span class="badge badge-pill badge-danger text-white"><i class="fa fa-tag"></i><B> Discount:&nbsp;<?php echo number_format($row['discount_per']) ?>&nbsp;%</B></span>
                                     </div>
									<?php
									}
									?>
									 
                                     <div class="card-img-top d-flex justify-content-center" style="max-height: 30vh;overflow: hidden">
                                     <img class="img-fluid" src="admin/assets/uploads/<?php echo $row['image_path'] ?>" alt="Card image cap">
                                       
                                     </div>
                                      <div class="float-right align-top d-flex">
                                     </div>
                                     <div class="card-body prod-item">
                                         <p><B>Title:</B> <?php echo $row['title'] ?></p>
                                         <p><B>Author:</B> <?php echo $row['author'] ?></p>
                                         <small>
										 <p><B>Category:</B>
                                            <?php 
                                          $cats = '';
                                          $cat = explode(',', $row['category_ids']);
                                          foreach ($cat as $key => $value) {
                                            if(!empty($cats)){
                                              $cats .=", ";
                                            }
                                            if(isset($cat_arr[$value])){
                                              $cats .= $cat_arr[$value];
                                            }
                                          }
                                          echo $cats;
                                          ?>
                                            
                                            </small>
                                          </p>
										  
								<!-- Customer ratings ceil if funtion for round nearest large integer-->
										  
                                         <p class="truncate"><?php echo $row['description'] ?></p>
                                        <?php
										$rates = $conn->query("SELECT rate from rating where book_id = '".$row['id']."'");
										$count = 0;
										$toral_rate = 0;
										$book_rate = 0;
										while($rate_row=$rates->fetch_assoc()){
											$count++;
											$toral_rate+=$rate_row['rate'];
										}
										if($toral_rate > 0){
											$book_rate = ceil($toral_rate/$count);
										}
										if($book_rate==0){
										?>
                                        <p>
                                        <img src="assets/img/gray.png" height="20">
                                        <img src="assets/img/gray.png" height="20">
                                        <img src="assets/img/gray.png" height="20">
                                        <img src="assets/img/gray.png" height="20">
                                        <img src="assets/img/gray.png" height="20">
                                        </p>
                                        <p>&nbsp;</p>
                                        <?php
										}elseif($book_rate==1){
										?> 
                                        <p>
                                        <img src="assets/img/yellow.png" height="20">
                                        <img src="assets/img/gray.png" height="20">
                                        <img src="assets/img/gray.png" height="20">
                                        <img src="assets/img/gray.png" height="20">
                                        <img src="assets/img/gray.png" height="20">
                                        </p>
                                        <p>&nbsp;</p>                                        
                                        <?php
										}elseif($book_rate==2){
										?>
                                        <p>
                                        <img src="assets/img/yellow.png" height="20">
                                        <img src="assets/img/yellow.png" height="20">
                                        <img src="assets/img/gray.png" height="20">
                                        <img src="assets/img/gray.png" height="20">
                                        <img src="assets/img/gray.png" height="20">
                                        </p>
                                        <p>&nbsp;</p>                                        
                                        <?php
										}elseif($book_rate==3){
										?>
                                        <p>
                                        <img src="assets/img/yellow.png" height="20">
                                        <img src="assets/img/yellow.png" height="20">
                                        <img src="assets/img/yellow.png" height="20">
                                        <img src="assets/img/gray.png" height="20">
                                        <img src="assets/img/gray.png" height="20">
                                        </p>
                                        <p>&nbsp;</p>                                                                                
                                        <?php
										}elseif($book_rate==4){
										?>
                                        <p>
                                        <img src="assets/img/yellow.png" height="20">
                                        <img src="assets/img/yellow.png" height="20">
                                        <img src="assets/img/yellow.png" height="20">
                                        <img src="assets/img/yellow.png" height="20">
                                        <img src="assets/img/gray.png" height="20">
                                        </p>
                                        <p>&nbsp;</p>                                                                                
                                        <?php
										}elseif($book_rate==5){
										?>
                                        <p>
                                        <img src="assets/img/yellow.png" height="20">
                                        <img src="assets/img/yellow.png" height="20">
                                        <img src="assets/img/yellow.png" height="20">
                                        <img src="assets/img/yellow.png" height="20">
                                        <img src="assets/img/yellow.png" height="20">
                                        </p>
                                        <p>&nbsp;</p>                                                                                
                                        <?php
										}
										?>
                                        <?php if(isset($_SESSION['login_id'])){ ?>
                                        <button class="btn btn-primary btn-sm view_prod" type="button" data-id="<?php echo $row['id'] ?>"> View</button>						
												<?php if(!isset($_REQUEST['wish'])){ ?>
                                        			<button class="btn btn-primary btn-sm" onClick="add_wishlist(<?php echo $row['id'] ?>);" type="button" data-id="<?php echo $row['id'] ?>"> Add to Wish List</button>
                                        		<?php }else{?>
                                                	<button class="btn btn-danger btn-sm" onclick="location.href='index.php?page=home&wish=1&del=<?php echo $row['id'] ?>';" type="button" data-id="<?php echo $row['id'] ?>"> Remove</button>
                                                <?php } ?>
										<?php }else{ ?>
                                        <button onClick="view_login();" class="btn btn-primary btn-sm" type="button" > View</button>
                                        <button onClick="view_login();" class="btn btn-primary btn-sm" type="button" > Add to Wish List</button>
										<?php } ?>
                                     </div>
                                 </div>
                             </div>
                            <?php endwhile; ?>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

       
<script>
    $('#cat-list li').click(function(){
        location.href = $(this).attr('data-href')
    })
     $('#cat-list li').each(function(){
        var id = '<?php echo $cid > 0 ? $cid : 'all' ?>';
        if(id == $(this).attr('data-id')){
            $(this).addClass('active')
        }
    })
     $('.view_prod').click(function(){
        uni_modal_right('View Book','view_prod.php?id='+$(this).attr('data-id'))
     })
</script>