<?php
    include 'db_connect.php';
    $year = isset($_GET['year']) ? $_GET['year'] : date('Y');
?>
<div class="container-fluid">
    <div class="col-lg-12">
        <div class="card">
            <div class="card_body">
            <div class="row justify-content-center pt-4">
                <label for="" class="mt-2"><h5><B>Fast Moving Books for Year</B></h5></label>
                <div class="col-sm-3">
                	<?php
					$curr_year = date('Y');
					?>
                	<select name="year" id="year" class="form-control">
						<?php
						for($i=0; $i<5; $i++){ 
						?>
                        <option value="<?php echo $curr_year-$i; ?>" <?php if($year==$curr_year-$i){ echo "selected";}?>><?php echo $curr_year-$i; ?></option>
                        <?php
						}
						?>
					</select>                    
                </div>
            </div>
            <hr>
            <div class="col-md-12">
                <table class="table table-bordered" id='report-list'>
                    <thead>
                        <tr>
                            <th class="text-center">#</th>
                            <th class="">ISBN</th>
                            <th class="">Book Title</th>
                            <th class="">QTY</th>
                            <th class="">Unit Price</th>
                            <th class="">Total Price</th>
                        </tr>
                    </thead>
                    <tbody>
                      <?php
                      $i = 1;
                      $total = 0;
                      $orders = $conn->query("SELECT book_id, sum(ol.qty) as book_count FROM order_list as ol, orders as o where o.id = ol.order_id and o.status = 1 and date_format(o.date_created,'%Y') = '$year' group by book_id order by book_count desc ");
                      if($orders->num_rows > 0):
                      while($row = $orders->fetch_array()):
                        //echo $row['book_id']."-".$row['book_count']."<br>";
						$items = $conn->query("SELECT * FROM books where id = '".$row['book_id']."'");
                      	$item_row = $items->fetch_array();
                        //$total += $roww['price']*$roww['qty'];
                      ?>
                      <tr>
                        <td class="text-center"><?php echo $i++ ?></td>
                        <td>
                            <p class="text-center"> <b><?php echo $item_row['isbn']; ?></b></p>
                        </td>
                        <td>
                            <p class="text-left"> <b><?php echo ucwords($item_row['title']); ?></b></p>
                        </td>
                        <td>
                            <p class="text-right"> <b><?php echo $row['book_count']; ?></b></p>
                        </td>
                        <td>
                            <p class="text-right"> <b><?php echo number_format($item_row['price'],2) ?></b></p>
                        </td>
                        <td>
                            <p class="text-right"> <b><?php echo number_format($item_row['price']*$row['book_count'],2) ?></b></p>
                        </td>
                    </tr>
                    <?php 
                    endwhile;
                        else:
                    ?>
                    <tr>
                            <th class="text-center" colspan="6">No Data.</th>
                    </tr>
                    <?php 
                        endif;
                    ?>
                    </tbody>
                </table>
                <hr>
                <div class="col-md-12 mb-4">
                    <center>
                        <button class="btn btn-success btn-sm col-sm-3" type="button" id="print"><i class="fa fa-print"></i> Print</button>
                    </center>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>
<noscript>
    <style>
        table#report-list{
            width:100%;
            border-collapse:collapse
        }
        table#report-list td,table#report-list th{
            border:1px solid
        }
        p{
            margin:unset;
        }
        .text-center{
            text-align:center
        }
        .text-right{
            text-align:right
        }
    </style>
</noscript>
<script>
$('#year').change(function(){
    location.replace('index.php?page=fast_moving_report&year='+$(this).val())
})
$('#report-list').dataTable()
$('#print').click(function(){
            $('#report-list').dataTable().fnDestroy()
        var _c = $('#report-list').clone();
        var ns = $('noscript').clone();
            ns.append(_c)
        var nw = window.open('','_blank','width=900,height=600')
        nw.document.write('<p class="text-center"><b>Fast Moving Books for Year <?php echo $year; ?></b></p>')
        nw.document.write(ns.html())
        nw.document.close()
        nw.print()
        setTimeout(() => {
            nw.close()
            $('#report-list').dataTable()
        }, 500);
    })
	
</script>