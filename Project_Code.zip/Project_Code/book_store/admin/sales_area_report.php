<?php
    include 'db_connect.php';
?>
<div class="container-fluid">
    <div class="col-lg-12">
        <div class="card">
            <div class="card_body">
            <div class="row justify-content-center pt-4">
                <label for="" class="mt-2"><h5><B>Lowest Book Selling Areas</B></h5></label>
            </div>
            <hr>
            <div class="col-md-12">
                <table class="table table-bordered" id='report-list'>
                    <thead>
                        <tr>
                            <th class="text-center">#</th>
                            <th class="">Area</th>
                            <th class="">Total Quantity of Books Sale</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
					$i = 1;						  
                    $location = $conn->query("SELECT c.city,sum(ol.qty) as city_qty FROM customers as c, orders as o, order_list as ol where ol.order_id = o.id and o.customer_id = c.id and o.status='1' group by c.city order by city_qty limit 10");
					if($location->num_rows > 0){
					  	while($row = $location->fetch_array()){
					?>
                      <tr>
                        <td class="text-center"><?php echo $i++ ?></td>
                        <td>
                            <p class="text-left"><b><?php echo $row['city']; ?></b></p>
                        </td>
                        <td>
                            <p class="text-center"> <b><?php echo $row['city_qty']; ?></b></p>
                        </td>
                    </tr>
				  <?php 
					  }
				  }else{
				  ?>
                    <tr>
                            <th class="text-center" colspan="3">No Data.</th>
                    </tr>
                  <?php
				  }
				  ?> 
                    </tbody>
                </table>
                <hr>
                <div class="col-md-12 mb-4">
                    <center>
                        <button class="btn btn-success btn-sm col-sm-3" type="button" id="print"><i class="fa fa-print"></i> Print</button>
                    </center>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>
<noscript>
    <style>
        table#report-list{
            width:100%;
            border-collapse:collapse
        }
        table#report-list td,table#report-list th{
            border:1px solid
        }
        p{
            margin:unset;
        }
        .text-center{
            text-align:center
        }
        .text-right{
            text-align:right
        }
    </style>
</noscript>
<script>
$('#area').change(function(){
    location.replace('index.php?page=book_sales_report&area='+$(this).val())
})
$('#report-list').dataTable()
$('#print').click(function(){
            $('#report-list').dataTable().fnDestroy()
        var _c = $('#report-list').clone();
        var ns = $('noscript').clone();
            ns.append(_c)
        var nw = window.open('','_blank','width=900,height=600')
        nw.document.write('<p class="text-center"><b>Lowest Book Selling Areas</b></p>')
        nw.document.write(ns.html())
        nw.document.close()
        nw.print()
        setTimeout(() => {
            nw.close()
            $('#report-list').dataTable()
        }, 500);
    })
	
</script>