<?php include "db_connect.php" ?>
<?php 
if(isset($_GET['id'])){
	$qry = $conn->query("SELECT * FROM books where id = ".$_GET['id']);
	foreach($qry->fetch_array() as $k => $v){
		$$k = $v;
	}
}
?>
	<!-- Form Panel for add New Book-->
<div class="container-fluid">
	<form action="" id="manage-book">
			<input type="hidden" name="id" value="<?php echo isset($id) ? $id : '' ?>">
		<div class="col-lg-12">
					<b class="text-muted"><h3>Informations of Book</h3></b>
			<div class="row">
				<div class="col-md-6 border-right">
					<div class="form-group">
						<label class="label control-label">Title</label>
						<input type="text" class="form-control form-control-sm w-100" name="title" required value="<?php echo isset($title) ? $title : '' ?>">
					</div>
					<div class="form-group">
						<label class="label control-label">ISBN</label>
						<input type="number" class="form-control form-control-sm w-100" name="isbn" required value="<?php echo isset($isbn) ? $isbn : '' ?>">
					</div>
					<div class="form-group">
						<label class="label control-label">Author</label>
						<input type="text" class="form-control form-control-sm w-100" name="author" required value="<?php echo isset($author) ? $author : '' ?>">
					</div>
					<div class="form-group">
						<label class="label control-label">Publisher</label>
						<input type="text" class="form-control form-control-sm w-100" name="publisher" required value="<?php echo isset($publisher) ? $publisher : '' ?>">
					</div>
					<div class="form-group">
						<label class="label control-label">Description</label>
						<textarea name="description" id="" cols="30" rows="4" class="form-control" required><?php echo isset($description) ? $description : '' ?></textarea>
					</div>
					
					
				</div>
				<div class="col-md-6">
					
					<div class="form-group">
						<label class="label control-label">Dimensions (cm)</label>
						<input type="text" class="form-control form-control-sm w-100" name="dimensions" required value="<?php echo isset($dimensions) ? $dimensions : '' ?>">
					</div>
					<div class="form-group">
						<label class="label control-label">Weight (kg)</label>
						<input type="text" class="form-control form-control-sm w-100" name="weight" required value="<?php echo isset($weight) ? $weight : '' ?>">
					</div>
					<div class="form-group">
						<label class="label control-label">Category</label>
						<select name="category_ids[]" id="" class="custom-select custom-select-sm select2" required multiple="multiple">
							<option value=""></option>
							<?php
							$categories = $conn->query("SELECT * FROM categories order by name asc");
							while($row= $categories->fetch_assoc()):
							?>
							<option value="<?php echo $row['id'] ?>" <?php echo isset($category_ids) && !empty($category_ids) &&  in_array($row['id'],explode(',',$category_ids)) ? 'selected' : '' ?>><?php echo ucwords($row['name']) ?></option>
						<?php endwhile; ?>
						</select>
					</div>
					<div class="form-group">
						<label class="label control-label">Price</label>
						<input type="text" class="form-control form-control-sm w-100 text-right number text-right" name="price" required value="<?php echo isset($price) ? $price : '' ?>">
					</div>
					<div class="form-group">
						<label class="label control-label">Discount(%)</label>
                        <select name="discount_per" id="discount_per"  class="form-control form-control-sm w-100 text-right number text-right" >
                        	<option value="0">No Discount</option>
                            <option value="5" <?php echo isset($discount_per) && $discount_per == 5 ? "selected" : '' ?> >5%</option>
                            <option value="10" <?php echo isset($discount_per) && $discount_per == 10 ? "selected" : '' ?> >10%</option>
                            <option value="15" <?php echo isset($discount_per) && $discount_per == 15 ? "selected" : '' ?> >15%</option>
                            <option value="20" <?php echo isset($discount_per) && $discount_per == 20 ? "selected" : '' ?> >20%</option>
                            <option value="25" <?php echo isset($discount_per) && $discount_per == 25 ? "selected" : '' ?> >25%</option>
                            <option value="30" <?php echo isset($discount_per) && $discount_per == 30 ? "selected" : '' ?> >30%</option>
                            <option value="35" <?php echo isset($discount_per) && $discount_per == 35 ? "selected" : '' ?> >35%</option>
                            <option value="40" <?php echo isset($discount_per) && $discount_per == 40 ? "selected" : '' ?> >40%</option>
                            <option value="45" <?php echo isset($discount_per) && $discount_per == 45 ? "selected" : '' ?> >45%</option>
                            <option value="50" <?php echo isset($discount_per) && $discount_per == 50 ? "selected" : '' ?> >50%</option>
                            <option value="55" <?php echo isset($discount_per) && $discount_per == 55 ? "selected" : '' ?> >55%</option>
                            <option value="60" <?php echo isset($discount_per) && $discount_per == 60 ? "selected" : '' ?> >60%</option>
                            <option value="65" <?php echo isset($discount_per) && $discount_per == 65 ? "selected" : '' ?> >65%</option>
                            <option value="70" <?php echo isset($discount_per) && $discount_per == 70 ? "selected" : '' ?> >70%</option>
                            <option value="75" <?php echo isset($discount_per) && $discount_per == 75 ? "selected" : '' ?> >75%</option>
                        </select>
					</div>
					<div class="form-group">
						<label for="" class="control-label">Image</label>
						<input type="file" class="form-control" name="img" onchange="displayImg(this,$(this))">
					</div>
					<div class="form-group">
						<img src="<?php echo isset($row['image_path']) ? 'assets/uploads/'.$row['image_path'] :'' ?>" alt="" id="cimg">
					</div>
					<div id="msg" class="form-group"></div>
				</div>
			</div>
		</div>

	</form>
</div>
<style>
	img#cimg{
		max-height: 10vh;
		max-width: 6vw;
	}

</style>
<script>
	$('.select2').select2({
		placeholder:"Please Select Here",
		width:'100%'
	})
	$('.number').on('input',function(){
        var val = $(this).val()
        val = val.replace(/,/g,'') 
        val = val > 0 ? val : 0;
        $(this).val(parseFloat(val).toLocaleString("en-US"))
    })
	function displayImg(input,_this) {
	    if (input.files && input.files[0]) {
	        var reader = new FileReader();
	        reader.onload = function (e) {
	        	$('#cimg').attr('src', e.target.result);
	        }

	        reader.readAsDataURL(input.files[0]);
	    }
	}
	$('#manage-book').submit(function(e){
		e.preventDefault()
		$('input').removeClass("border-danger")
		start_load()
		$('#msg').html('')
		$.ajax({
			url:'ajax.php?action=save_book',
			data: new FormData($(this)[0]),
		    cache: false,
		    contentType: false,
		    processData: false,
		    method: 'POST',
		    type: 'POST',
			error:err=>{
				console.log(err)
			},
			success:function(resp){
				if(resp == 1){
					alert_toast('Data successfully saved.',"success");
					setTimeout(function(){
						location.reload()
					},750)
				}
			}
		})
	})
</script>