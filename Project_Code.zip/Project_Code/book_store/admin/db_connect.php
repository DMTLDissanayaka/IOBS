<?php 
$conn= new mysqli('localhost','root','','iobs_db')or die("Could not connect to mysql".mysqli_error($con));
$_SESSION['email_generate'] = 1;
$_SESSION['email_sender'] = "bookshop@sofsysit.com";
date_default_timezone_set("Asia/Colombo");
?>