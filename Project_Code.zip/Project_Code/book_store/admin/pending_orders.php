<?php include('db_connect.php');?>

<div class="container-fluid">
	
	<div class="col-lg-12">
		<div class="row">
			<!-- Table Panel -->
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<b><h4>Pending order list to be confirm</h4></b>
					</div>
					<div class="card-body">
						<table class="table table-bordered" id='report-list'>
							<colgroup>
								<col width="5%">
								<col width="10%">
								<col width="10%">
								<col width="15%">
								<col width="10%">
								<col width="10%">
								<col width="15%">
								<col width="10%">
								<col width="15%">
							</colgroup>
							<thead>
								<tr>
									<th class="text-center">#</th>
									<th class="text-center">Order number</th>
									<th class="text-center">Date</th>
									<th class="text-center">Customer</th>
									<th class="text-center">Items</th>
									<th class="text-center">Total Amount</th>
									<th class="text-center">Payment Type</th>
                                    <th class="text-center">Status</th>
									<th class="text-center">Action</th>
								</tr>
							</thead>
							<tbody>
								<?php 
								$i = 1;
								$orders = $conn->query("SELECT o.*,c.name FROM orders o inner join customers c on c.id = o.customer_id where o.status = 0 order by unix_timestamp(o.date_created) asc ");
								while($row=$orders->fetch_assoc()):
									$tamount = $conn->query("SELECT sum(price * qty) as amount from order_list where order_id = ".$row['id'])->fetch_array()['amount'];
									$items = $conn->query("SELECT sum(qty) as items from order_list where order_id = ".$row['id'])->fetch_array()['items'];
								?>
								<tr>
									<td class="text-center"><?php echo $i++ ?></td>
									<td class="">
										<p><b><?php echo ucwords($row['id']) ?></b></p>
									</td>
									<td class="">
										<p><b><?php echo date("M d,Y",strtotime($row['date_created'])) ?></b></p>
									</td>
									<td class="">
										<p><b><?php echo ucwords($row['name']) ?></b></p>
									</td>
									<td class="text-right">
										<p><b><?php echo $items ?></b></p>
									</td>
									<td class="">
										<p class="text-right"><b><?php echo number_format($tamount,2) ?></b></p>
									</td>
                                    <td class="">
										<p class="">
                                        <b>
										<?php 
										if($row['pay_type']==1){
											echo "Online Payment";	
										}else{
											echo "Cash On Delivery";	
										}
										?>
                                        </b>
                                        </p>
									</td>
									<td class="text-center">
										<?php if($row['status'] == 0): ?>
											<span class="badge badge-primary">Pending</span>
										<?php elseif($row['status'] == 1): ?>
											<span class="badge badge-success">Confirmed</span>
										<?php elseif($row['status'] == 2): ?>
											<span class="badge badge-success">Comleted</span>
										<?php endif; ?>
									</td>
									<td class="text-center">
										<button class="btn btn-sm btn-primary edit_order" type="button" data-id="<?php echo $row['id'] ?>">View</button>
										<button class="btn btn-sm btn-danger delete_order" type="button" data-id="<?php echo $row['id'] ?>">Delete</button>
									</td>
								</tr>
								<?php endwhile; ?>
							</tbody>
						</table>
				        <hr>
						<div class="col-md-12 mb-4">
							<center>
								<button class="btn btn-success btn-sm col-sm-3" type="button" id="print"><i class="fa fa-print"></i> Print</button>
							</center>
						</div>
						
					</div>
				</div>
			</div>
			<!-- Table Panel -->
		</div>
	</div>	

</div>
<noscript>
<style>
	table#report-list{
		width:100%;
		border-collapse:collapse
	}
	table#report-list td,table#report-list th{
		border:1px solid
	}
	p{
		margin:unset;
	}
	.text-center{
		text-align:center
	}
	.text-right{
		text-align:right
	}
</style>
</noscript>
<script>
	$('#new_order').click(function(){
		uni_modal("New order","manage_order.php","large")
	})
	$('.edit_order').click(function(){
		uni_modal("Manage order Data","manage_order.php?id="+$(this).attr('data-id'),"large")
	})
	$('#manage-order').on('reset',function(){
		$('input:hidden').val('')
		$('.select2').val('').trigger('change')
	})
	
	$('#manage-order').submit(function(e){
		e.preventDefault()
		start_load()
		$.ajax({
			url:'ajax.php?action=save_order',
			data: new FormData($(this)[0]),
		    cache: false,
		    contentType: false,
		    processData: false,
		    method: 'POST',
		    type: 'POST',
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully added",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
				else if(resp==2){
					alert_toast("Data successfully updated",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	})
	$('.delete_order').click(function(){
		_conf("Are you sure to delete this order?","delete_order",[$(this).attr('data-id')])
	})
	function delete_order($id){
		start_load()
		$.ajax({
			url:'ajax.php?action=delete_order',
			method:'POST',
			data:{id:$id},
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully deleted",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	}
	$('#print').click(function(){
            $('#report-list').dataTable().fnDestroy()
        var _c = $('#report-list').clone();
        var ns = $('noscript').clone();
            ns.append(_c)
        var nw = window.open('','_blank','width=900,height=600')
        nw.document.write('<p class="text-center"><b>Pending order list <?php if(isset($item_row['isbn'])) echo $item_row['isbn']; ?></b></p>')
        nw.document.write(ns.html())
        nw.document.close()
        nw.print()
        setTimeout(() => {
            nw.close()
            $('#report-list').dataTable()
        }, 500);
    })
	
	$('table').dataTable()
	
</script>