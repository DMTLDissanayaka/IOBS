<?php include('db_connect.php');?>

<div class="container-fluid">
	
	<div class="col-lg-12">
		<div class="row">
			<!-- Table Panel -->
			<div class="col-md-12">
				<div class="card">
					<div class="card-header">
						<b><h4>Customer List</h4></b>
					</div>
					<div class="card-body">
						<table class="table table-bordered table-hover">
							<colgroup>
								
								<col width="5%">
								<col width="20%">
								<col width="15%">
								<col width="15%">
								<col width="15%">
								<col width="30%">
								
							</colgroup>
							<thead>
								<tr>
									<th class="text-center">#</th>
									<th class="text-center">Name</th>
									<th class="text-center">City</th>
									<th class="text-center">Age</th>
									<th class="text-center">Contact</th>
									<th class="text-center">E-mail</th>
									
								</tr>
							</thead>
							<tbody>
								<?php 
								$i = 1;
								$name = $conn->query("SELECT * FROM customers group by city order by city asc ");
								//$name = $conn->query("SELECT * FROM customers order by name asc ");
								while($row=$name->fetch_assoc()):
								?>
								<tr>
									<td class="text-center"><?php echo $i++ ?></td>
									<td class="">
										<p><b><?php echo ucwords($row['name']) ?></b></p>
									</td>
									<td class="">
										<p><b><?php echo ucwords($row['city']) ?></b></p>
									</td>
									<td class="">
										<p><b><?php echo ($row['age']) ?></b></p>
									</td>
									<td class="">
										<p><b><?php echo ($row['contact']) ?></b></p>
									</td>
									<td class="">
										<p><b><?php echo ($row['email']) ?></b></p>
									</td>
									
										<!--<button class="btn btn-sm btn-primary edit_order" type="button" data-id="<?php echo $row['id'] ?>">View</button>
										<button class="btn btn-sm btn-danger delete_order" type="button" data-id="<?php echo $row['id'] ?>">Delete</button>  -->
									</td>
								</tr>
								<?php endwhile; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<!-- Table Panel -->
		</div>
	</div>	

</div>
<style>
	
	
</style>
<script>
		
	$('table').dataTable()
	
</script>