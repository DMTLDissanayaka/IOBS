<?php
session_start();
ini_set('display_errors', 1);
Class Action {
	private $db;

	public function __construct() {
		ob_start();
   	include 'db_connect.php';
    
    $this->db = $conn;
	}
	function __destruct() {
	    $this->db->close();
	    ob_end_flush();
	}

	function login(){
		extract($_POST);
		$qry = $this->db->query("SELECT * FROM users where username = '".$username."' and password = '".md5($password)."' ");
		if($qry->num_rows > 0){
			foreach ($qry->fetch_array() as $key => $value) {
				if($key != 'passwors' && !is_numeric($key))
					$_SESSION['login_'.$key] = $value;
			}
				return 1;
		}else{
			return 3;
		}
	}
	function login2(){
		
		extract($_POST);		
		$qry = $this->db->query("SELECT * FROM customers where email = '".$email."' and password = '".md5($password)."' ");
		if($qry->num_rows > 0){
			foreach ($qry->fetch_array() as $key => $value) {
				if($key != 'passwors' && !is_numeric($key))
					$_SESSION['login_'.$key] = $value;
			}
				return 1;
		}else{
			return 3;
		}
	}
	function logout(){
		session_destroy();
		foreach ($_SESSION as $key => $value) {
			unset($_SESSION[$key]);
		}
		header("location:login.php");
	}
	function logout2(){
		session_destroy();
		foreach ($_SESSION as $key => $value) {
			unset($_SESSION[$key]);
		}
		header("location:../index.php");
	}

	function save_user(){
		extract($_POST);
		$data = " name = '$name' ";
		$data .= ", username = '$username' ";
		if(!empty($password))
		$data .= ", password = '".md5($password)."' ";
		$data .= ", type = '$type' ";
		$chk = $this->db->query("Select * from users where username = '$username' and id !='$id' ")->num_rows;
		if($chk > 0){
			return 2;
			exit;
		}
		if(empty($id)){
			$save = $this->db->query("INSERT INTO users set ".$data);
		}else{
			$save = $this->db->query("UPDATE users set ".$data." where id = ".$id);
		}
		if($save){
			return 1;
		}
	}
	function delete_user(){
		extract($_POST);
		$delete = $this->db->query("DELETE FROM users where id = ".$id);
		if($delete)
			return 1;
	}
	function signup(){

		$no_of_items = count($_REQUEST['category_ids']);
		$text = "";
		for($x = 0; $x < $no_of_items; $x++){
			if($x == 0){
				$text = $_REQUEST['category_ids'][$x];
			}else{
				$text = $text.", ".$_REQUEST['category_ids'][$x];
			}
		}

		extract($_POST);

		$data = " name = '$name' ";
		$data .= ", email = '$email' ";
		$data .= ", contact = '$contact' ";
		$data .= ", lname = '$lname' ";
		$data .= ", str_no = '$str_no' ";
		$data .= ", str_name = '$str_name' ";
		$data .= ", city = '$city' ";
		$data .= ", country = '$country' ";
		$data .= ", postal_code = '$postal_code' ";
		$data .= ", age = '$age' ";
		$data .= ", category_ids = '$text' ";
				
		$data .= ", password = '".md5($password)."' ";
		$chk   = $this->db->query("SELECT * from customers where email ='$email' ".(!empty($id) ? " and id != '$id' " : ''))->num_rows;
		if($chk > 0){
			return 3;
			exit;
		}
		
		if($password != $conf_password){
			return 5;
			exit;		
		}
		
		if(strlen($contact) != 10){
			return 6;
			exit;	
		}
		
		if(empty($id))
			$save = $this->db->query("INSERT INTO customers set $data");
		else
			$save = $this->db->query("UPDATE customers set $data where id=$id ");
		if($save){
			if(empty($id))
				$id = $this->db->insert_id;
				$qry = $this->db->query("SELECT * FROM customers where id = $id ");
				if($qry->num_rows > 0){
					foreach ($qry->fetch_array() as $key => $value) {
						if($key != 'password' && !is_numeric($key))
							$_SESSION['login_'.$key] = $value;
					}
						return 1;
				}else{
					return 3;
				}
		}
	}
	function update_account(){
		extract($_POST);
		$data = " name = '".$firstname.' '.$lastname."' ";
		$data .= ", username = '$email' ";
		if(!empty($password))
		$data .= ", password = '".md5($password)."' ";
		$chk = $this->db->query("SELECT * FROM users where username = '$email' and id != '{$_SESSION['login_id']}' ")->num_rows;
		if($chk > 0){
			return 2;
			exit;
		}
			$save = $this->db->query("UPDATE users set $data where id = '{$_SESSION['login_id']}' ");
		if($save){
			$data = '';
			foreach($_POST as $k => $v){
				if($k =='password')
					continue;
				if(empty($data) && !is_numeric($k) )
					$data = " $k = '$v' ";
				else
					$data .= ", $k = '$v' ";
			}
			if($_FILES['img']['tmp_name'] != ''){
							$fname = strtotime(date('y-m-d H:i')).'_'.$_FILES['img']['name'];
							$move = move_uploaded_file($_FILES['img']['tmp_name'],'assets/uploads/'. $fname);
							$data .= ", avatar = '$fname' ";

			}
			$save_alumni = $this->db->query("UPDATE alumnus_bio set $data where id = '{$_SESSION['bio']['id']}' ");
			if($data){
				foreach ($_SESSION as $key => $value) {
					unset($_SESSION[$key]);
				}
				$login = $this->login2();
				if($login)
				return 1;
			}
		}
	}
	function save_page_img(){
		extract($_POST);
		if($_FILES['img']['tmp_name'] != ''){
				$fname = strtotime(date('y-m-d H:i')).'_'.$_FILES['img']['name'];
				$move = move_uploaded_file($_FILES['img']['tmp_name'],'assets/uploads/'. $fname);
				if($move){
					$protocol = strtolower(substr($_SERVER["SERVER_PROTOCOL"],0,5))=='https'?'https':'http';
					$hostName = $_SERVER['HTTP_HOST'];
						$path =explode('/',$_SERVER['PHP_SELF']);
						$currentPath = '/'.$path[1]; 
   						 // $pathInfo = pathinfo($currentPath); 

					return json_encode(array('link'=>$protocol.'://'.$hostName.$currentPath.'/admin/assets/uploads/'.$fname));

				}
		}
	}

	function save_settings(){
		extract($_POST);
		$data = " name = '".str_replace("'","&#x2021;",$name)."' ";
		$data .= ", email = '$email' ";
		$data .= ", contact = '$contact' ";
		$data .= ", about_content = '".htmlentities(str_replace("'","&#x2021;",$about))."' ";
		if($_FILES['img']['tmp_name'] != ''){
						$fname = strtotime(date('y-m-d H:i')).'_'.$_FILES['img']['name'];
						$move = move_uploaded_file($_FILES['img']['tmp_name'],'assets/uploads/'. $fname);
					$data .= ", cover_img = '$fname' ";

		}
		
		// echo "INSERT INTO system_settings set ".$data;
		$chk = $this->db->query("SELECT * FROM system_settings");
		if($chk->num_rows > 0){
			$save = $this->db->query("UPDATE system_settings set ".$data);
		}else{
			$save = $this->db->query("INSERT INTO system_settings set ".$data);
		}
		if($save){
		$query = $this->db->query("SELECT * FROM system_settings limit 1")->fetch_array();
		foreach ($query as $key => $value) {
			if(!is_numeric($key))
				$_SESSION['system'][$key] = $value;
		}

			return 1;
				}
	}
	function save_category(){
		extract($_POST);
		$data = "";
		foreach($_POST as $k => $v){
			if(!in_array($k, array('id')) && !is_numeric($k)){
				if(empty($data)){
					//If category list empty add to data
					$data .= " $k='$v' ";
					//If category list is not empty add to data with , seperate
				}else{
					$data .= ", $k='$v' ";
				}
			}
		}
		$check = $this->db->query("SELECT * FROM categories where name ='$name' ".(!empty($id) ? " and id != {$id} " : ''))->num_rows;
		if($check > 0){
			return 2;
			exit;
		}
		if(empty($id)){
			$save = $this->db->query("INSERT INTO categories set $data");
		}else{
			$save = $this->db->query("UPDATE categories set $data where id = $id");
		}

		if($save)
			return 1;
	}
	function delete_category(){
		extract($_POST);
		$delete = $this->db->query("DELETE FROM categories where id = ".$id);
		if($delete){
			return 1;
		}
	}
	function save_book(){
		extract($_POST);
		$data = "";
		foreach($_POST as $k => $v){
			if(!in_array($k, array('id','category_ids','price')) && !is_numeric($k)){
				if(empty($data)){
					$data .= " $k='$v' ";
				}else{
					$data .= ", $k='$v' ";
				}
			}
		}
		$data .= ", price = '".str_replace(',','',$price)."' ";
		$data .= ", category_ids = '".implode(',',$category_ids)."' ";
		if($_FILES['img']['tmp_name'] != ''){
						$fname = strtotime(date('y-m-d H:i')).'_'.$_FILES['img']['name'];
						$move = move_uploaded_file($_FILES['img']['tmp_name'],'assets/uploads/'. $fname);
					$data .= ", image_path = '$fname' ";

		}
		if(empty($id)){
			$save = $this->db->query("INSERT INTO books set $data");
		}else{
			$save = $this->db->query("UPDATE books set $data where id = $id");
		}

		if($save)
			return 1;
	}
	function add_stock(){
		extract($_POST);
		$save = $this->db->query("UPDATE books set stock_balance = stock_balance+'".$new_stock."' where id = $id");

		if($save)
			return 1;
	}
	function delete_book(){
		extract($_POST);
		$delete = $this->db->query("DELETE FROM books where id = ".$id);
		if($delete){
			return 1;
		}
	}
	function add_to_wish(){
		extract($_POST);
		$data = " customer_id = {$_SESSION['login_id']} ";
		$data .= ", book_id = $book_id ";
		$check = $this->db->query("SELECT * FROM wish_list where book_id = $book_id and customer_id ={$_SESSION['login_id']} ");
		$id= $check->num_rows > 0 ? $check->fetch_array()['wish_id'] : '';
		if(!empty($id)){
			return 2;
		}else{
			$save = $this->db->query("INSERT INTO wish_list (book_id,customer_id) VALUES ('$book_id','{$_SESSION['login_id']}')");
		}
		if($save){
			return 1;
		}
	}
	
	function add_to_cart(){
		extract($_POST);
		if($discount_per > 0){
			$price = $price-(($price*$discount_per)/100);	
		}
		
		$data = " customer_id = {$_SESSION['login_id']} ";
		$data .= ", book_id = $book_id ";
		$data .= ", qty= $qty";
		$data .= ", price= $price";
		$data .= ", discount_per= $discount_per";
		$check = $this->db->query("SELECT * FROM cart where book_id = $book_id and customer_id ={$_SESSION['login_id']} ");
		$id= $check->num_rows > 0 ? $check->fetch_array()['id'] : '';
		
		//my- working- 
		$save_stock = $this->db->query("UPDATE books set stock_balance = stock_balance-$qty where id = $book_id");
	
		
		if(!empty($id))
			$save = $this->db->query("UPDATE cart set qty = qty+$qty where id = $id");
		else
			$save = $this->db->query("INSERT INTO cart set $data");
		if($save){
			return 1;
		}
	}
	
	function add_rate(){
		extract($_POST);
		$data = " customer_id = {$_SESSION['login_id']} ";
		$data .= ", book_id = $book_id ";
		$data .= ", rate= $rate";
		$check = $this->db->query("SELECT * FROM rating where book_id = $book_id and customer_id ={$_SESSION['login_id']} ");
		$id= $check->num_rows > 0 ? $check->fetch_array()['rate_id'] : '';
		if(!empty($id))
			$save = $this->db->query("UPDATE rating set rate = '".$rate."', book_id ='".$book_id."', customer_id = '".$_SESSION['login_id']."' where rate_id ='".$id."'");
		else
			$save = $this->db->query("INSERT INTO rating set $data");
		if($save){
			return $rate;
		}
	}
	
	function get_cart_count(){
		$qry = $this->db->query("SELECT c.*,b.image_path,b.title FROM cart c inner join books b on b.id = c.book_id where c.customer_id ={$_SESSION['login_id']}");
		$data = array();
		$count = 0 ; 
		$data['list']=array();
		while ($row=$qry->fetch_array()) {
			$data['list'][]=$row;
			$count += $row['qty'];
		}
		$data['count'] = $count;
		return json_encode($data);
	}
	function update_cart(){
		extract($_POST);
		$save = $this->db->query("UPDATE cart set qty = $qty where id = $id");
		if($save){
			return 1;
		}

	}
	function delete_cart(){
		extract($_POST);
		//my- working- 
		//add to stock	
				$qry = $this->db->query("SELECT c.*,b.image_path,b.title,b.author FROM cart c inner join books b on b.id = c.book_id where c.id =$id ");
				if($qry->num_rows > 0){
					while($row= $qry->fetch_array()){
						$save_stock = $this->db->query("UPDATE books set stock_balance = stock_balance+'".$row['qty']."' where id = '".$row['book_id']."'");	
					}
				}
		
		$del = $this->db->query("DELETE FROM cart where id =  $id");
		if($del)
			return 1;
	}

	function delete_shopping_cart(){
		extract($_POST);
		$delete = $this->db->query("DELETE FROM cart where id = ".$id);
		
		if($delete){
			return 1;
		}
	}
	function save_order(){
		extract($_POST);
		$data = " customer_id = {$_SESSION['login_id']} ";
		$data .= ", address = '$address' ";
		$data .= ", pay_type = '$pay_type' ";
		$save = $this->db->query("INSERT INTO orders set $data");
		if($save){
			$id = $this->db->insert_id;
			$qry = $this->db->query("SELECT * FROM cart where customer_id ={$_SESSION['login_id']}");
			while($row = $qry->fetch_array()){
				$data = " order_id = $id ";
				$data .= ", book_id = {$row['book_id']} ";
				$data .= ", qty = {$row['qty']} ";
				$data .= ", price = '{$row['price']}'";
				if($order[] = $this->db->query("INSERT INTO order_list set $data")){
					$this->db->query("DELETE FROM cart where id ='{$row['id']}' ");
					$this->db->query("DELETE FROM view_history where book_id ='".$row['book_id']."' and user_id ='".$_SESSION['login_id']."'");
				}
			}
			
			//send email
			$qry_email = $this->db->query("SELECT email FROM customers where id =".$_SESSION['login_id']);
			$row_email= $qry_email->fetch_array();
			if(strlen($row_email['email']) > 0 && $_SESSION['email_generate'] == 1){
				$htmlContent = ' 
					<p>Dear Valued Customer,</p>
					<p>Your Order is Placed Successfully.</p>
					<p>You will receive an email, once your package is dispatch from our store.</p>
					<p>Best regards,</p>
					<p>Interactive Online Book Shop</p>
					';

				$to = $row_email['email'];
				$from = $_SESSION['email_sender'];
				$fromName = 'Interactive Online Book Shop';
				$subject = 'Order Placed - Interactive Online Book Shop';

				// Header for sender info 
				$headers = "From: $fromName"." <".$from.">"; 
		 
				// Boundary  
				$semi_rand = md5(time());  
				$mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";  
		 
				// Headers for attachment  
				$headers .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " boundary=\"{$mime_boundary}\""; 
			 
				// Multipart boundary  
				$message = "--{$mime_boundary}\n" . "Content-Type: text/html; charset=\"UTF-8\"\n" . 
				"Content-Transfer-Encoding: 7bit\n\n" . $htmlContent . "\n\n";  
		
				$message .= "--{$mime_boundary}--"; 
				$returnpath = "-f" . $from; 
			 
				// Send email 
				$mail = @mail($to, $subject, $message, $headers, $returnpath);  
				
				// Email sending status 
				//return $mail?1:0; 					
			}
			
			if(isset($order))
				return 1;
		}
	}
	function update_order(){
		extract($_POST);
		$save = $this->db->query("UPDATE orders set status = $status,delivery_ref_no = '$delivery_ref_no' where id = $id");
		if($save){
			if($status == 1 && $pre_status == 0){
				//deduct stock	
				$qry = $this->db->query("SELECT o.*,b.image_path,b.title,b.author FROM order_list o inner join books b on b.id = o.book_id where o.order_id =$id ");
				if($qry->num_rows > 0){
					while($row= $qry->fetch_array()){
						$save_stock = $this->db->query("UPDATE books set stock_balance = stock_balance-'".$row['qty']."' where id = '".$row['book_id']."'");	
					}
				}
				//send email
				$qry_email = $this->db->query("SELECT c.email FROM customers c inner join orders o on c.id = o.customer_id where o.id =$id");
				$row_email= $qry_email->fetch_array();
				if(strlen($row_email['email']) > 0 && $_SESSION['email_generate'] == 1){
					$order_details = "";
					
					$book_list = $this->db->query("SELECT ol.qty,ol.price,b.title FROM order_list as ol, books as b where ol.book_id = b.id and ol.order_id =$id ");
					if($book_list->num_rows > 0){
						$order_total = 0;
						while($book_row= $book_list->fetch_array()){
							$order_details.="<p>Book:".$book_row['title']." | Qty:".$book_row['qty']."</p>";
							$order_total+=($book_row['qty']*$book_row['price']);
						}
						$order_details.="<p>Order Total:".number_format($order_total,2)."</p>";
					}
					
					$htmlContent = ' 
						<p>Dear Valued Customer,</p>
						<p>Your Order is Confirmed.</p>
						<p>Order Details:</p>
						'.$order_details.'
						<p>Please use the below delivery reference number to Track your book(s).</p>
						<p>Delivery Ref:'.$delivery_ref_no.'</p>
						<p>Best regards,</p>
						<p>Interactive Online Book Shop</p>
						';

					$to = $row_email['email'];
					$from = $_SESSION['email_sender'];
					$fromName = 'Interactive Online Book Shop';
					$subject = 'Order Confirmation - Interactive Online Book Shop';

					// Header for sender info 
					$headers = "From: $fromName"." <".$from.">"; 
			 
					// Boundary  
					$semi_rand = md5(time());  
					$mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";  
			 
					// Headers for attachment  
					$headers .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " boundary=\"{$mime_boundary}\""; 
				 
					// Multipart boundary  
					$message = "--{$mime_boundary}\n" . "Content-Type: text/html; charset=\"UTF-8\"\n" . 
					"Content-Transfer-Encoding: 7bit\n\n" . $htmlContent . "\n\n";  
			
					$message .= "--{$mime_boundary}--"; 
					$returnpath = "-f" . $from; 
				 
					// Send email 
					$mail = @mail($to, $subject, $message, $headers, $returnpath);  
					
					// Email sending status 
					//return $mail?1:0; 					
				}
				
			}elseif($status == 0 && $pre_status == 1){
				//add to stock	
				$qry = $this->db->query("SELECT o.*,b.image_path,b.title,b.author FROM order_list o inner join books b on b.id = o.book_id where o.order_id =$id ");
				if($qry->num_rows > 0){
					while($row= $qry->fetch_array()){
						$save_stock = $this->db->query("UPDATE books set stock_balance = stock_balance+'".$row['qty']."' where id = '".$row['book_id']."'");	
					}
				}
			}
			return 1;
		}
	}
	function update_order1(){
		extract($_POST);
		$save = $this->db->query("UPDATE orders set status = $status,delivery_ref_no = '$delivery_ref_no' where id = $id");
		if($save){
			if($status == 1 && $pre_status == 0){
				//deduct stock	
				$qry = $this->db->query("SELECT o.*,b.image_path,b.title,b.author FROM order_list o inner join books b on b.id = o.book_id where o.order_id =$id ");
				if($qry->num_rows > 0){
					while($row= $qry->fetch_array()){
						//$save_stock = $this->db->query("UPDATE books set stock_balance = stock_balance-'".$row['qty']."' where id = '".$row['book_id']."'");	
					}
				}
				//send email
				$qry_email = $this->db->query("SELECT c.email FROM customers c inner join orders o on c.id = o.customer_id where o.id =$id");
				$row_email= $qry_email->fetch_array();
				if(strlen($row_email['email']) > 0 && $_SESSION['email_generate'] == 1){
					$order_details = "";
					
					$book_list = $this->db->query("SELECT ol.qty,ol.price,b.title FROM order_list as ol, books as b where ol.book_id = b.id and ol.order_id =$id ");
					if($book_list->num_rows > 0){
						$order_total = 0;
						while($book_row= $book_list->fetch_array()){
							$order_details.="<p>Book:".$book_row['title']." | Qty:".$book_row['qty']."</p>";
							$order_total+=($book_row['qty']*$book_row['price']);
						}
						$order_details.="<p>Order Total:".number_format($order_total,2)."</p>";
					}
					
					$htmlContent = ' 
						<p>Dear Valued Customer,</p>
						<p>Your Order is Confirmed.</p>
						<p>Order Details:</p>
						'.$order_details.'
						<p>Please use the below delivery reference number to Track your book(s).</p>
						<p>Delivery Ref:'.$delivery_ref_no.'</p>
						<p>Best regards,</p>
						<p>Interactive Online Book Shop</p>
						';

					$to = $row_email['email'];
					$from = $_SESSION['email_sender'];
					$fromName = 'Interactive Online Book Shop';
					$subject = 'Order Confirmation - Interactive Online Book Shop';

					// Header for sender info 
					$headers = "From: $fromName"." <".$from.">"; 
			 
					// Boundary  
					$semi_rand = md5(time());  
					$mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";  
			 
					// Headers for attachment  
					$headers .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " boundary=\"{$mime_boundary}\""; 
				 
					// Multipart boundary  
					$message = "--{$mime_boundary}\n" . "Content-Type: text/html; charset=\"UTF-8\"\n" . 
					"Content-Transfer-Encoding: 7bit\n\n" . $htmlContent . "\n\n";  
			
					$message .= "--{$mime_boundary}--"; 
					$returnpath = "-f" . $from; 
				 
					// Send email 
					$mail = @mail($to, $subject, $message, $headers, $returnpath);  
					
					// Email sending status 
					//return $mail?1:0; 					
				}
				
			}elseif($status == 0 && $pre_status == 1){
				//add to stock	
				$qry = $this->db->query("SELECT o.*,b.image_path,b.title,b.author FROM order_list o inner join books b on b.id = o.book_id where o.order_id =$id ");
				if($qry->num_rows > 0){
					while($row= $qry->fetch_array()){
						$save_stock = $this->db->query("UPDATE books set stock_balance = stock_balance+'".$row['qty']."' where id = '".$row['book_id']."'");	
					}
				}
			}
			return 1;
		}
	}
	
	function delete_order(){
		extract($_POST);
		
		//add to stock	
				$qry = $this->db->query("SELECT o.*,b.image_path,b.title,b.author FROM order_list o inner join books b on b.id = o.book_id where o.order_id =$id ");
				if($qry->num_rows > 0){
					while($row= $qry->fetch_array()){
						$save_stock = $this->db->query("UPDATE books set stock_balance = stock_balance+'".$row['qty']."' where id = '".$row['book_id']."'");	
					}
				}
		
		$delete = $this->db->query("DELETE FROM orders where id = ".$id);
		$delete2 = $this->db->query("DELETE FROM order_list where order_id = ".$id);
		if($delete && $delete2){
			return 1;
		}
	}
}