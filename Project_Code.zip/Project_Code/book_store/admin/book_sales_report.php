<?php
    include 'db_connect.php';
    $isbn = isset($_GET['isbn']) ? $_GET['isbn'] : '';
?>
<div class="container-fluid">
    <div class="col-lg-12">
        <div class="card">
            <div class="card_body">
            <div class="row justify-content-center pt-4">
                <label for="" class="mt-2"><h5><B>5 Years Sale History of Book</B></h5></label>
                <div class="col-sm-3">
                	<select name="isbn" id="isbn" class="form-control">
						<option value="" >Select ISBN</option>
						<?php
						$books = $conn->query("SELECT * FROM books order by isbn asc");
                     	while($book_row = $books->fetch_array()){
						?>
                        <option value="<?php echo $book_row['id']; ?>" <?php if($isbn==$book_row['id']){ echo "selected";}?>><?php echo $book_row['isbn']."-".$book_row['title']; ?></option>
                        <?php
						}
						?>
					</select>                    
                </div>
            </div>
            <hr>
            <div class="col-md-12">
				<?php
				$items = $conn->query("SELECT * FROM books where id = '".$isbn."'");
                if($items->num_rows > 0){
					$item_row = $items->fetch_array();
				?>
                <table class="table">
                    <tr>
                        <td class="text-right">ISBN:</td>
                        <td class="text-left"><b><?php echo $item_row['isbn'];?></b></td>
                        <td class="text-right">Book Title:</td>
                        <td class="text-left"><b><?php echo $item_row['title'];?></b></td>
                    </tr>
                </table>
                <?php
				}
				?>
                <table class="table table-bordered" id='report-list'>
                    <thead>
                        <tr>
                            <th class="text-center">#</th>
                            <th class="">Year</th>
                            <th class="">QTY</th>
                            <th class="">Unit Price</th>
                            <th class="">Total Price</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
					if($items->num_rows > 0){  
					  $cur_year = date('Y');
                      for($i=0; $i<5; $i++){
						  $year = $cur_year-$i;
						  $orders = $conn->query("SELECT book_id, sum(ol.qty) as book_count FROM order_list as ol, orders as o where book_id = '".$isbn."' and o.id = ol.order_id and (o.status = 1 or o.status = 2) and date_format(o.date_created,'%Y') = '".$year."' group by book_id order by book_count desc ");
						  	$row = $orders->fetch_array();
                      //while($row = $orders->fetch_array()):
                      ?>
                      <tr>
                        <td class="text-center"><?php echo $i+1; ?></td>
                        <td>
                            <p class="text-center"> <b><?php echo $year; ?></b></p>
                        </td>
                        <td>
                            <p class="text-center"> <b><?php if($row['book_count'] > 0){ echo $row['book_count'];}else{ echo "0"; } ?></b></p>
                        </td>
                        <td>
                            <p class="text-right"> <b><?php echo number_format($item_row['price'],2) ?></b></p>
                        </td>
                        <td>
                            <p class="text-right"> <b><?php echo number_format($item_row['price']*$row['book_count'],2) ?></b></p>
                        </td>
                    </tr>
                    <?php 
					  }
					}else{
                    ?>
                        <tr>
                                <th class="text-center" colspan="5">No Data.</th>
                        </tr>
                    <?php
					}
					?>
                    </tbody>
                </table>
                <hr>
                <div class="col-md-12 mb-4">
                    <center>
                        <button class="btn btn-success btn-sm col-sm-3" type="button" id="print"><i class="fa fa-print"></i> Print</button>
                    </center>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>
<noscript>
    <style>
        table#report-list{
            width:100%;
            border-collapse:collapse
        }
        table#report-list td,table#report-list th{
            border:1px solid
        }
        p{
            margin:unset;
        }
        .text-center{
            text-align:center
        }
        .text-right{
            text-align:right
        }
    </style>
</noscript>
<script>
$('#isbn').change(function(){
    location.replace('index.php?page=book_sales_report&isbn='+$(this).val())
})
$('#report-list').dataTable()
$('#print').click(function(){
            $('#report-list').dataTable().fnDestroy()
        var _c = $('#report-list').clone();
        var ns = $('noscript').clone();
            ns.append(_c)
        var nw = window.open('','_blank','width=900,height=600')
        nw.document.write('<p class="text-center"><b>5 Year Sale History of Book <?php if(isset($item_row['isbn'])) echo $item_row['isbn']; ?></b></p>')
        nw.document.write(ns.html())
        nw.document.close()
        nw.print()
        setTimeout(() => {
            nw.close()
            $('#report-list').dataTable()
        }, 500);
    })
	
</script>